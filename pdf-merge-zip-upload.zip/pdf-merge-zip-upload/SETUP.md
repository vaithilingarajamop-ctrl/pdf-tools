# Setup Instructions — PDF Merge & ZIP Uploader

This extension already has a **fixed Extension ID** baked in via the `key`
field in manifest.json, so it will be the same no matter who loads it:

**Extension ID: `dlpbpojlchnkajfccmljpcnonanmkmjn`**

## Step 1: Load the extension
1. Open `chrome://extensions`
2. Turn on "Developer mode" (top right)
3. Click "Load unpacked" and select this folder
4. Confirm the Extension ID shown matches `dlpbpojlchnkajfccmljpcnonanmkmjn`

## Step 2: Create a NEW Google Cloud project + OAuth Client
This should be a fresh project, separate from any other extension's project.

1. Go to https://console.cloud.google.com/projectcreate — create a new project
   (e.g. "PDF Merge Zip Uploader")
2. With that new project selected, go to
   https://console.cloud.google.com/apis/credentials
3. Click **Create Credentials → OAuth client ID**
4. Application type: **Chrome Extension**
5. Paste the Extension ID above: `dlpbpojlchnkajfccmljpcnonanmkmjn`
6. Copy the generated Client ID (looks like `123456-abc...apps.googleusercontent.com`)

## Step 3: Enable the Drive API
1. Go to https://console.cloud.google.com/apis/library/drive.googleapis.com
2. Click **Enable**

## Step 4: Configure OAuth consent screen
1. Go to https://console.cloud.google.com/apis/credentials/consent
2. Fill in the app name, support email, etc.
3. If in "Testing" mode, add your Google account (and anyone else who'll
   use this extension) under **Test users**

## Step 5: Update manifest.json
Open `manifest.json` and replace:
```
"client_id": "PASTE_NEW_CLIENT_ID_HERE.apps.googleusercontent.com"
```
with your real Client ID from Step 2.

## Step 6: Reload and test
1. `chrome://extensions` → reload icon on the extension
2. Click the extension icon → **Test Login**
3. If successful, you're ready to go — download a PDF or ZIP and try it out.

## Notes
- This extension only tracks and handles **PDF** and **ZIP** files —
  Excel support was removed for this build.
- Scope used is the full `https://www.googleapis.com/auth/drive` (needed to
  browse existing Drive folders). If you only need to create/upload new
  files and never need to browse folders, you could narrow this to
  `drive.file` in manifest.json for a less sensitive permission.
