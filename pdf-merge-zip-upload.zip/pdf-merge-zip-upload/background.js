// Tracks the most recently downloaded PDF(s). Upload happens ONLY when the
// user clicks "Upload to Drive" in the popup — no automatic/background
// upload. This avoids look-alike "auto exfiltration" behavior that some
// corporate EDR/antivirus tools flag and kill Chrome for.

function bumpStat(key, delta) {
  chrome.storage.session.get(["stats"], (data) => {
    const stats = data.stats || { downloaded: 0, merged: 0, deleted: 0 };
    stats[key] = (stats[key] || 0) + delta;
    chrome.storage.session.set({ stats });
  });
}

function getFileType(filename) {
  const lower = filename.toLowerCase();
  if (lower.endsWith(".pdf")) return "pdf";
  if (lower.endsWith(".zip")) return "zip";
  if (lower.endsWith(".xlsx") || lower.endsWith(".xls") || lower.endsWith(".csv")) return "excel";
  if (lower.endsWith(".docx") || lower.endsWith(".doc")) return "word";
  return null;
}

function mimeTypeFor(fileType, filename) {
  if (fileType === "pdf") return "application/pdf";
  if (fileType === "zip") return "application/zip";
  if (fileType === "excel") {
    return filename.toLowerCase().endsWith(".csv")
      ? "text/csv"
      : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  }
  if (fileType === "word") return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
  return "application/octet-stream";
}

chrome.downloads.onChanged.addListener((delta) => {
  if (delta.state && delta.state.current === "complete") {
    chrome.downloads.search({ id: delta.id }, (results) => {
      if (!results || !results[0]) return;
      const item = results[0];
      const filename = item.filename || "";
      const fileType = getFileType(filename);

      if (fileType) {
        const fileName = filename.split(/[\\/]/).pop();
        const newEntry = {
          id: item.id,
          fileName: fileName,
          fileType: fileType,
          sourceUrl: item.finalUrl || item.url || "",
          time: Date.now()
        };

        // Always read the latest list from storage first — the in-memory
        // array does NOT survive service worker restarts in Manifest V3.
        chrome.storage.session.get(["recentPdfs"], (data) => {
          const existing = data.recentPdfs || [];
          // avoid duplicate entries for the same download id
          const filtered = existing.filter((p) => p.id !== newEntry.id);
          const updated = [newEntry, ...filtered]; // no limit — keep full history
          chrome.storage.session.set({ recentPdfs: updated });
        });

        bumpStat("downloaded", 1);
      }
    });
  }
});

function getAuthToken() {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      const err = chrome.runtime.lastError;
      if (err || !token) {
        reject(err ? err.message : "no token returned");
      } else {
        resolve(token);
      }
    });
  });
}

async function listDriveFolders(parentId) {
  const token = await getAuthToken();
  const parent = parentId || "root";
  const query = encodeURIComponent(
    `'${parent}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false`
  );
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name)&pageSize=100&orderBy=name`,
    { headers: { Authorization: "Bearer " + token } }
  );
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error ? data.error.message : "Could not list folders");
  }
  return data.files || [];
}

async function loadBlobFromDb(id) {
  const db = await openBlobDb();
  return new Promise((resolve) => {
    const tx = db.transaction("blobs", "readonly");
    const req = tx.objectStore("blobs").get(id);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => resolve(null);
  });
}

async function uploadToDrive(pdfEntry, folderId) {
  const { sourceUrl, fileType } = pdfEntry;
  const fileName = pdfEntry.renamedName || pdfEntry.fileName;
  const token = await getAuthToken();

  let fileBlob = await loadBlobFromDb("attached-" + pdfEntry.id);
  if (!fileBlob) {
    if (!sourceUrl) {
      throw new Error("No source URL available for this file.");
    }
    const fileResponse = await fetchSourceFile(sourceUrl);
    if (!fileResponse.ok) {
      throw new Error("Could not re-fetch source file: HTTP " + fileResponse.status);
    }
    fileBlob = await fileResponse.blob();
  }

  const metadata = { name: fileName, mimeType: mimeTypeFor(fileType, fileName) };
  if (folderId) {
    metadata.parents = [folderId];
  }
  const form = new FormData();
  form.append("metadata", new Blob([JSON.stringify(metadata)], { type: "application/json" }));
  form.append("file", fileBlob);

  const uploadResponse = await fetch(
    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
    {
      method: "POST",
      headers: { Authorization: "Bearer " + token },
      body: form
    }
  );

  const result = await uploadResponse.json();
  if (!uploadResponse.ok) {
    throw new Error(result.error ? result.error.message : "Unknown upload error");
  }
  return result;
}

async function uploadBytesToDrive(arrayBuffer, fileName, mimeType, folderId) {
  const token = await getAuthToken();
  const metadata = { name: fileName, mimeType: mimeType || "application/octet-stream" };
  if (folderId) metadata.parents = [folderId];

  const fileBlob = new Blob([arrayBuffer], { type: mimeType || "application/octet-stream" });
  const form = new FormData();
  form.append("metadata", new Blob([JSON.stringify(metadata)], { type: "application/json" }));
  form.append("file", fileBlob);

  const res = await fetch(
    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
    { method: "POST", headers: { Authorization: "Bearer " + token }, body: form }
  );
  const result = await res.json();
  if (!res.ok) {
    throw new Error(result.error ? result.error.message : "Unknown upload error");
  }
  return result;
}

// Listen for manual upload requests from the popup
function markUploadedInStorage(id) {
  return new Promise((resolve) => {
    chrome.storage.session.get(["recentPdfs"], (data) => {
      const pdfs = data.recentPdfs || [];
      const updated = pdfs.map((p) => (String(p.id) === String(id) ? { ...p, uploaded: true } : p));
      chrome.storage.session.set({ recentPdfs: updated }, resolve);
    });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "UPLOAD_PDF") {
    uploadToDrive(msg.pdf, msg.folderId)
      .then((result) => {
        bumpStat("uploaded", 1);
        sendResponse({ success: true, result });
      })
      .catch((err) => sendResponse({ success: false, error: err.message || String(err) }));
    return true; // keep channel open for async response
  }
  if (msg.type === "UPLOAD_BLOB") {
    // Bytes are sent from the popup so the actual network upload runs here
    // in the background service worker — it keeps going even if the popup
    // closes (e.g. user clicks elsewhere) mid-upload.
    uploadBytesToDrive(msg.arrayBuffer, msg.fileName, msg.mimeType, msg.folderId)
      .then(async (result) => {
        bumpStat("uploaded", 1);
        if (msg.entryId) {
          await markUploadedInStorage(msg.entryId);
        }
        sendResponse({ success: true, result });
      })
      .catch((err) => sendResponse({ success: false, error: err.message || String(err) }));
    return true;
  }
  if (msg.type === "LIST_FOLDERS") {
    listDriveFolders(msg.parentId)
      .then((folders) => sendResponse({ success: true, folders }))
      .catch((err) => sendResponse({ success: false, error: err.message || String(err) }));
    return true;
  }
  if (msg.type === "DELETE_PDF") {
    chrome.storage.session.get(["recentPdfs", "deletedPdfs"], (data) => {
      const pdfs = data.recentPdfs || [];
      const deleted = data.deletedPdfs || [];
      const target = pdfs.find((p) => String(p.id) === String(msg.id));
      const remaining = pdfs.filter((p) => String(p.id) !== String(msg.id));

      if (target) {
        const archived = { ...target, deletedAt: Date.now() };
        const updatedDeleted = [archived, ...deleted.filter((p) => String(p.id) !== String(msg.id))];
        chrome.storage.session.set(
          { recentPdfs: remaining, deletedPdfs: updatedDeleted },
          () => sendResponse({ success: true })
        );
      } else {
        sendResponse({ success: true });
      }
    });
    bumpStat("deleted", 1);
    return true;
  }
  if (msg.type === "RESTORE_PDF") {
    chrome.storage.session.get(["recentPdfs", "deletedPdfs"], (data) => {
      const pdfs = data.recentPdfs || [];
      const deleted = data.deletedPdfs || [];
      const target = deleted.find((p) => String(p.id) === String(msg.id));
      const remainingDeleted = deleted.filter((p) => String(p.id) !== String(msg.id));

      if (target) {
        const restored = { ...target };
        delete restored.deletedAt;
        const updatedPdfs = [restored, ...pdfs.filter((p) => String(p.id) !== String(msg.id))];
        chrome.storage.session.set(
          { recentPdfs: updatedPdfs, deletedPdfs: remainingDeleted },
          () => sendResponse({ success: true })
        );
      } else {
        sendResponse({ success: false, error: "Not found in deleted archive" });
      }
    });
    return true;
  }
});
async function trimGoogleSheetToUsedRange(spreadsheetId, token) {
  const metaRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets(properties(sheetId,title,gridProperties))`,
    { headers: { Authorization: "Bearer " + token } }
  );
  const meta = await metaRes.json();
  if (!metaRes.ok) {
    throw new Error("Could not read sheet metadata: " + (meta.error ? meta.error.message : metaRes.status));
  }
  if (!meta.sheets) {
    return { totalSheets: 0, deletedSheets: 0, trimmedSheets: 0 };
  }

  const requests = [];
  let sheetsRemaining = meta.sheets.length;
  let deletedCount = 0;
  let trimmedCount = 0;

  for (const sheet of meta.sheets) {
    const { sheetId, title, gridProperties } = sheet.properties;
    const totalRows = gridProperties.rowCount || 0;
    const totalCols = gridProperties.columnCount || 0;

    const range = `'${title}'!A1:ZZ${totalRows}`;
    const valuesRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`,
      { headers: { Authorization: "Bearer " + token } }
    );
    const valuesData = await valuesRes.json();
    if (!valuesRes.ok) {
      throw new Error(
        "Could not read sheet values for '" + title + "': " + (valuesData.error ? valuesData.error.message : valuesRes.status)
      );
    }
    const values = valuesData.values || [];

    // Count cells that actually have visible, non-blank text — a sheet
    // full of only empty strings/whitespace should be treated as empty.
    const nonEmptyCellCount = values.reduce(
      (count, row) => count + row.filter((cell) => String(cell).trim() !== "").length,
      0
    );

    // A whole tab with no real content becomes its own (mostly blank)
    // page(s) when exported — delete it outright rather than just
    // trimming its grid. Never delete the last remaining sheet.
    if (nonEmptyCellCount === 0 && sheetsRemaining > 1) {
      requests.push({ deleteSheet: { sheetId } });
      sheetsRemaining -= 1;
      deletedCount += 1;
      continue;
    }

    const usedRowCount = values.length;
    const usedColCount = values.reduce((max, row) => Math.max(max, row.length), 0);

    const keepRows = Math.max(usedRowCount, 1);
    const keepCols = Math.max(usedColCount, 1);

    if (totalRows > keepRows) {
      requests.push({
        deleteDimension: {
          range: { sheetId, dimension: "ROWS", startIndex: keepRows, endIndex: totalRows }
        }
      });
      trimmedCount += 1;
    }
    if (totalCols > keepCols) {
      requests.push({
        deleteDimension: {
          range: { sheetId, dimension: "COLUMNS", startIndex: keepCols, endIndex: totalCols }
        }
      });
    }
  }

  if (requests.length > 0) {
    const batchRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
      method: "POST",
      headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" },
      body: JSON.stringify({ requests })
    });
    const batchData = await batchRes.json();
    if (!batchRes.ok) {
      throw new Error("batchUpdate failed: " + (batchData.error ? batchData.error.message : batchRes.status));
    }
  }

  return { totalSheets: meta.sheets.length, deletedSheets: deletedCount, trimmedSheets: trimmedCount };
}

// Some hosts (Slack, WhatsApp Web CDN, etc.) reject requests when
// credentials are included with a wildcard CORS policy; others require
// credentials to authorize the download at all. Try both so either case
// works.
async function fetchSourceFile(url) {
  try {
    const res = await fetch(url, { credentials: "include" });
    if (res.ok) return res;
  } catch (err) {
    console.warn("fetch with credentials failed, retrying without:", err.message || err);
  }
  return fetch(url, { credentials: "omit" });
}

async function convertViaGoogleDrive(fileBlob, fileName, fileType) {
  const token = await getAuthToken();
  const targetMime =
    fileType === "excel" ? "application/vnd.google-apps.spreadsheet" : "application/vnd.google-apps.document";

  // Step 1: upload the file WITH a Google-native target mimeType — Drive
  // auto-converts it into a real Google Sheet / Google Doc on upload,
  // preserving all original colors/formatting.
  const metadata = { name: fileName, mimeType: targetMime };
  const form = new FormData();
  form.append("metadata", new Blob([JSON.stringify(metadata)], { type: "application/json" }));
  form.append("file", fileBlob);

  const uploadRes = await fetch(
    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
    { method: "POST", headers: { Authorization: "Bearer " + token }, body: form }
  );
  const uploadData = await uploadRes.json();
  if (!uploadRes.ok) {
    throw new Error(uploadData.error ? uploadData.error.message : "Could not convert file on Drive");
  }
  const tempFileId = uploadData.id;

  try {
    // Step 1.5: for spreadsheets, trim the converted sheet's grid to the
    // real used range so there are no extra blank pages in the PDF.
    if (fileType === "excel") {
      try {
        await trimGoogleSheetToUsedRange(tempFileId, token);
      } catch (trimErr) {
        console.error("Trim step failed:", trimErr);
        // Best-effort — continue to export even if trimming failed.
      }
    }

    // Step 2: export that Google Sheet/Doc as a real PDF — Google's own
    // rendering engine does the layout, so formatting matches the original.
    const exportRes = await fetch(
      `https://www.googleapis.com/drive/v3/files/${tempFileId}/export?mimeType=application/pdf`,
      { headers: { Authorization: "Bearer " + token } }
    );
    if (!exportRes.ok) {
      const errData = await exportRes.json().catch(() => ({}));
      throw new Error(errData.error ? errData.error.message : "PDF export failed");
    }
    return await exportRes.blob();
  } finally {
    // Step 3: clean up the temporary Google Sheet/Doc either way.
    fetch(`https://www.googleapis.com/drive/v3/files/${tempFileId}`, {
      method: "DELETE",
      headers: { Authorization: "Bearer " + token }
    }).catch(() => {});
  }
}

// ---------- Persistent blob storage (shared with popup via IndexedDB) ----------
function openBlobDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("driveUploaderBlobs", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("blobs");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function saveBlobToDb(id, blob) {
  const db = await openBlobDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("blobs", "readwrite");
    tx.objectStore("blobs").put(blob, id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// ---------- Excel/Word -> PDF conversion (runs fully in the background so
// it survives the popup closing) ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "CONVERT_TO_PDF") {
    (async () => {
      try {
        const pdf = msg.pdf;
        let sourceBlob;

        if (msg.manualBase64) {
          const binary = atob(msg.manualBase64);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
          sourceBlob = new Blob([bytes], { type: msg.manualMimeType || "application/octet-stream" });
        } else {
          const attached = await loadBlobFromDb("attached-" + pdf.id);
          if (attached) {
            sourceBlob = attached;
          } else {
            const res = await fetchSourceFile(pdf.sourceUrl);
            if (!res.ok) throw new Error("Could not fetch source file: HTTP " + res.status);
            sourceBlob = await res.blob();
          }
        }

        const pdfBlob = await convertViaGoogleDrive(sourceBlob, pdf.fileName, pdf.fileType);

        const baseName = (pdf.renamedName || pdf.fileName).replace(/\.[^.]+$/, "");
        const newName = baseName + "_converted.pdf";
        const newId = "converted-" + Date.now();
        await saveBlobToDb(newId, pdfBlob);

        const data = await new Promise((resolve) => chrome.storage.session.get(["recentPdfs"], resolve));
        const all = data.recentPdfs || [];
        const markedAll = all.map((p) => (String(p.id) === String(pdf.id) ? { ...p, converted: true } : p));
        const newEntry = {
          id: newId,
          fileName: newName,
          fileType: "pdf",
          sourceUrl: "",
          isLocal: true,
          convertedFrom: pdf.fileType,
          time: Date.now()
        };
        const updatedList = [newEntry, ...markedAll];
        await new Promise((resolve) => chrome.storage.session.set({ recentPdfs: updatedList }, resolve));

        bumpStat(pdf.fileType === "excel" ? "excelToPdf" : "wordToPdf", 1);
        sendResponse({ success: true, newName });
      } catch (err) {
        sendResponse({ success: false, error: err.message || String(err) });
      }
    })();
    return true; // keep the message channel open for the async response
  }
});
