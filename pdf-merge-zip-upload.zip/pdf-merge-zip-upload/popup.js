document.getElementById("extId").textContent = chrome.runtime.id;

// Some hosts (Slack, WhatsApp Web CDN, etc.) reject requests when
// credentials are included with a wildcard CORS policy; others require
// credentials to authorize the download at all. Try both so either case
// works — fixes blank/failed merges and conversions for third-party files.
async function fetchSourceFilePopup(url) {
  try {
    const res = await fetch(url, { credentials: "include" });
    if (res.ok) return res;
  } catch (err) {
    console.warn("fetch with credentials failed, retrying without:", err.message || err);
  }
  return fetch(url, { credentials: "omit" });
}

// Persistent blob storage for merged/converted PDFs, so "Open" and
// "Upload" keep working even after the popup is closed and reopened
// (unlike a plain in-memory object, which resets every time this script
// re-runs). IndexedDB is shared between this popup and the background
// service worker since both live at the same extension origin.
function openBlobDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("driveUploaderBlobs", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("blobs");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function saveBlobToDb(id, blob) {
  const db = await openBlobDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("blobs", "readwrite");
    tx.objectStore("blobs").put(blob, id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function loadBlobFromDb(id) {
  const db = await openBlobDb();
  return new Promise((resolve) => {
    const tx = db.transaction("blobs", "readonly");
    const req = tx.objectStore("blobs").get(id);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => resolve(null);
  });
}

async function deleteBlobFromDb(id) {
  const db = await openBlobDb();
  return new Promise((resolve) => {
    const tx = db.transaction("blobs", "readwrite");
    tx.objectStore("blobs").delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => resolve();
  });
}

// Tracks the order in which checkboxes were clicked (not list order), so
// merges follow the order the user selected files in. Maps id -> sequence
// number at the moment it was checked (higher = checked later).
const selectionSeqMap = {};
let selectionCounter = 0;

const statusEl = document.getElementById("status");
const pdfListEl = document.getElementById("pdfList");
const folderBrowserEl = document.getElementById("folderBrowser");
const breadcrumbEl = document.getElementById("breadcrumb");
const selectedFolderEl = document.getElementById("selectedFolder");

document.getElementById("testAuth").addEventListener("click", () => {
  statusEl.textContent = "Requesting token...";
  chrome.identity.getAuthToken({ interactive: true }, (token) => {
    const err = chrome.runtime.lastError;
    if (err || !token) {
      statusEl.textContent = "FAILED:\n" + (err ? err.message : "no token returned");
    } else {
      statusEl.textContent = "SUCCESS! Token received.\nLogin is working correctly.";
    }
  });
});

// ---------- Folder browser ----------
// path is an array of {id, name} representing the breadcrumb trail.
// path[0] is always the virtual root { id: null, name: "My Drive" }.
let path = [{ id: null, name: "My Drive" }];
let currentFolders = [];

function renderBreadcrumb() {
  breadcrumbEl.innerHTML = "";
  path.forEach((crumb, idx) => {
    const span = document.createElement("span");
    span.className = "crumb";
    span.textContent = crumb.name;
    span.addEventListener("click", () => {
      path = path.slice(0, idx + 1);
      loadFolderLevel(crumb.id);
    });
    breadcrumbEl.appendChild(span);
    if (idx < path.length - 1) {
      breadcrumbEl.appendChild(document.createTextNode(" / "));
    }
  });
}

function renderFolderList() {
  folderBrowserEl.innerHTML = "";
  if (currentFolders.length === 0) {
    folderBrowserEl.innerHTML = '<div class="folder-row" style="color:#888; cursor:default;">No subfolders here.</div>';
    return;
  }
  currentFolders.forEach((folder) => {
    const row = document.createElement("div");
    row.className = "folder-row";
    row.textContent = "📁 " + folder.name;
    row.addEventListener("click", () => {
      path.push({ id: folder.id, name: folder.name });
      loadFolderLevel(folder.id);
    });
    folderBrowserEl.appendChild(row);
  });
}

function loadFolderLevel(parentId) {
  statusEl.textContent = "Loading folders...";
  chrome.runtime.sendMessage({ type: "LIST_FOLDERS", parentId }, (response) => {
    if (response && response.success) {
      currentFolders = response.folders;
      renderBreadcrumb();
      renderFolderList();
      statusEl.textContent = "";
    } else {
      statusEl.textContent = "FAILED to load folders: " + (response ? response.error : "no response");
    }
  });
}

document.getElementById("selectHereBtn").addEventListener("click", () => {
  const current = path[path.length - 1];
  const trail = path
    .slice(1) // drop the virtual "My Drive" root label
    .map((p) => p.name);
  const lastThree = trail.slice(-3);
  const displayPath = lastThree.length > 0 ? lastThree.join(" > ") : "My Drive (root)";

  chrome.storage.local.set({ lastFolderId: current.id, lastFolderName: displayPath });
  selectedFolderEl.textContent = "Selected: " + displayPath;
  statusEl.textContent = "Folder selected: " + displayPath;
});

// Restore last selection + start browsing from root
chrome.storage.local.get(["lastFolderName"], (data) => {
  if (data.lastFolderName) {
    selectedFolderEl.textContent = "Selected: " + data.lastFolderName;
  }
});
loadFolderLevel(null);

// ---------- Recent PDFs ----------
// ---------- Recent Files (tabbed by type) ----------
const tabsEl = document.getElementById("tabs");
const TABS = [
  { key: "pdf", label: "📄 PDF" },
  { key: "merged", label: "🔗 Merge PDFs" },
  { key: "excel", label: "📊 Excel" },
  { key: "excelPdf", label: "📊➜📄 Excel→PDF" },
  { key: "word", label: "📝 Word" },
  { key: "wordPdf", label: "📝➜📄 Word→PDF" },
  { key: "zip", label: "🗜 ZIP" }
];
let activeTab = "pdf";

function renderTabs() {
  tabsEl.innerHTML = "";
  TABS.forEach((tab) => {
    const btn = document.createElement("button");
    btn.className = "tab-btn" + (tab.key === activeTab ? " active" : "");
    btn.textContent = tab.label;
    btn.addEventListener("click", () => {
      activeTab = tab.key;
      viewMode = "tabs";
      statFilter = null;
      filterBannerEl.style.display = "none";
      tabsEl.style.display = "flex";
      renderTabs();
      renderList();
    });
    tabsEl.appendChild(btn);
  });
  const mergeBtn = document.getElementById("mergePdfBtn");
  if (mergeBtn) {
    mergeBtn.style.display = ["pdf", "excelPdf", "wordPdf", "merged"].includes(activeTab) ? "block" : "none";
  }
  const bulkUploadBtn = document.getElementById("bulkUploadBtn");
  if (bulkUploadBtn) {
    bulkUploadBtn.style.display = activeTab === "merged" ? "block" : "none";
  }
}
renderTabs();

// ---------- Stats bar (clickable to filter) ----------
const statsBarEl = document.getElementById("statsBar");
const searchBoxEl = document.getElementById("searchBox");
const filterBannerEl = document.getElementById("filterBanner");
const filterBannerTextEl = document.getElementById("filterBannerText");

// viewMode: "tabs" (normal PDF/Excel/ZIP tabs) or "stat" (filtered by a stat)
let viewMode = "tabs";
let statFilter = null; // "downloaded" | "uploaded" | "pending" | "deleted"

function bumpStatPopup(key, delta) {
  chrome.storage.session.get(["stats"], (data) => {
    const stats = data.stats || { downloaded: 0, merged: 0, excelToPdf: 0, wordToPdf: 0, deleted: 0 };
    stats[key] = (stats[key] || 0) + delta;
    chrome.storage.session.set({ stats }, renderStats);
  });
}

function renderStats() {
  chrome.storage.session.get(["stats", "recentPdfs", "deletedPdfs"], (data) => {
    const stats = data.stats || { downloaded: 0, merged: 0, excelToPdf: 0, wordToPdf: 0, deleted: 0 };
    const deleted = data.deletedPdfs || [];

    const items = [
      { key: "downloaded", label: "Downloads", value: stats.downloaded || 0, color: "#00897b" },
      { key: "merged", label: "Merge PDFs", value: stats.merged || 0, color: "#8e24aa" },
      { key: "excelToPdf", label: "Excel→PDF", value: stats.excelToPdf || 0, color: "#1a73e8" },
      { key: "wordToPdf", label: "Word→PDF", value: stats.wordToPdf || 0, color: "#e65100" },
      { key: "deleted", label: "Deleted", value: deleted.length, color: "#d93025" }
    ];

    statsBarEl.innerHTML = "";
    items.forEach((item) => {
      const pill = document.createElement("div");
      pill.className = "stat-pill";
      pill.innerHTML = `<span class="stat-num" style="color:${item.color}">${item.value}</span>${item.label}`;
      pill.addEventListener("click", () => {
        viewMode = "stat";
        statFilter = item.key;
        filterBannerTextEl.textContent = "Showing: " + item.label + " files";
        filterBannerEl.style.display = "flex";
        tabsEl.style.display = "none";
        renderList();
      });
      statsBarEl.appendChild(pill);
    });
  });
}
renderStats();

document.getElementById("clearFilterBtn").addEventListener("click", () => {
  viewMode = "tabs";
  statFilter = null;
  filterBannerEl.style.display = "none";
  tabsEl.style.display = "flex";
  renderList();
});

searchBoxEl.addEventListener("input", () => renderList());

function renameFile(id, newName) {
  chrome.storage.session.get(["recentPdfs"], (data) => {
    const pdfs = data.recentPdfs || [];
    const updated = pdfs.map((p) => (p.id === id ? { ...p, renamedName: newName } : p));
    chrome.storage.session.set({ recentPdfs: updated }, () => {
      statusEl.textContent = "Renamed to: " + newName;
    });
  });
}

function markUploaded(id) {
  return new Promise((resolve) => {
    chrome.storage.session.get(["recentPdfs"], (data) => {
      const pdfs = data.recentPdfs || [];
      const updated = pdfs.map((p) => (String(p.id) === String(id) ? { ...p, uploaded: true } : p));
      chrome.storage.session.set({ recentPdfs: updated }, resolve);
    });
  });
}

function renderList() {
  const keys = ["recentPdfs", "deletedPdfs"];
  chrome.storage.session.get(keys, (data) => {
    const all = data.recentPdfs || [];
    const deletedAll = data.deletedPdfs || [];
    const query = searchBoxEl.value.trim().toLowerCase();
    pdfListEl.innerHTML = "";
    updateSelectedCount();

    let source;
    let isDeletedView = false;

    if (viewMode === "stat") {
      if (statFilter === "deleted") {
        source = deletedAll;
        isDeletedView = true;
      } else if (statFilter === "merged") {
        source = all.filter((p) => p.fileType === "pdf" && p.isLocal);
      } else {
        source = all; // "downloaded" = everything currently tracked
      }
    } else {
      if (activeTab === "pdf") {
        source = all.filter((p) => p.fileType === "pdf" && !p.isLocal);
      } else if (activeTab === "merged") {
        source = all.filter((p) => p.fileType === "pdf" && p.isLocal && !p.convertedFrom);
      } else if (activeTab === "excelPdf") {
        source = all.filter((p) => p.fileType === "pdf" && p.isLocal && p.convertedFrom === "excel");
      } else if (activeTab === "wordPdf") {
        source = all.filter((p) => p.fileType === "pdf" && p.isLocal && p.convertedFrom === "word");
      } else {
        source = all.filter((p) => p.fileType === activeTab);
      }
    }

    if (query) {
      source = source.filter((p) =>
        (p.renamedName || p.fileName || "").toLowerCase().includes(query)
      );
    }

    if (source.length === 0) {
      pdfListEl.innerHTML = '<div class="empty">No files match.</div>';
      return;
    }

    if (isDeletedView) {
      source.forEach((pdf) => {
        const row = document.createElement("div");
        row.className = "pdf-item";
        row.style.flexWrap = "wrap";

        const name = document.createElement("div");
        name.style.flex = "1";
        name.style.fontSize = "11px";
        name.textContent = pdf.renamedName || pdf.fileName;

        const status = document.createElement("span");
        status.style.fontSize = "10px";
        status.style.marginRight = "6px";
        status.style.fontWeight = "600";

        if (pdf.fileType === "zip") {
          status.style.color = "#555";
          status.textContent = "ZIP file";
        } else if (pdf.isLocal) {
          status.style.color = "#8e24aa";
          status.textContent = "Was: Merged output";
        } else if (pdf.merged) {
          status.style.color = "#8e24aa";
          status.textContent = "Was: Merged";
        } else {
          status.style.color = "#888";
          status.textContent = "Was: Not merged";
        }

        const restoreBtn = document.createElement("button");
        restoreBtn.textContent = "♻ Restore";
        restoreBtn.style.background = "#0b8043";
        restoreBtn.addEventListener("click", () => {
          chrome.runtime.sendMessage({ type: "RESTORE_PDF", id: pdf.id }, (response) => {
            if (response && response.success) {
              statusEl.textContent = "Restored: " + (pdf.renamedName || pdf.fileName);
              renderList();
              renderStats();
            } else {
              statusEl.textContent = "Restore failed: " + (response ? response.error : "unknown");
            }
          });
        });

        row.appendChild(name);
        row.appendChild(status);
        row.appendChild(restoreBtn);
        pdfListEl.appendChild(row);
      });
      return;
    }

    source.forEach((pdf) => {
      const row = document.createElement("div");
      row.className = "pdf-item";
      row.style.flexWrap = "wrap";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.className = "bulk-check";
      checkbox.dataset.id = pdf.id;
      checkbox.checked = String(pdf.id) in selectionSeqMap;

      const orderBadge = document.createElement("span");
      orderBadge.className = "order-badge";
      orderBadge.style.fontSize = "10px";
      orderBadge.style.fontWeight = "700";
      orderBadge.style.color = "white";
      orderBadge.style.background = "#1a73e8";
      orderBadge.style.borderRadius = "50%";
      orderBadge.style.width = "16px";
      orderBadge.style.height = "16px";
      orderBadge.style.display = checkbox.checked ? "flex" : "none";
      orderBadge.style.alignItems = "center";
      orderBadge.style.justifyContent = "center";
      orderBadge.style.marginRight = "2px";

      checkbox.addEventListener("change", () => {
        const id = String(pdf.id);
        if (checkbox.checked) {
          selectionCounter += 1;
          selectionSeqMap[id] = selectionCounter;
        } else {
          delete selectionSeqMap[id];
        }
        updateSelectedCount();
        renumberOrderBadges();
      });

      const nameInput = document.createElement("input");
      nameInput.type = "text";
      nameInput.value = pdf.renamedName || pdf.fileName;
      nameInput.title = "Rename before upload";
      nameInput.style.flex = "1";
      nameInput.style.minWidth = "90px";
      nameInput.style.fontSize = "11px";
      nameInput.style.border = "1px solid #ccc";
      nameInput.style.borderRadius = "4px";
      nameInput.style.padding = "3px 5px";
      nameInput.addEventListener("change", () => {
        renameFile(pdf.id, nameInput.value);
      });

      const status = document.createElement("span");
      status.style.fontSize = "10px";
      status.style.marginRight = "6px";
      status.style.fontWeight = "600";

      const isPlainPdf = pdf.fileType === "pdf" && !pdf.isLocal;
      const isPlainOffice = (pdf.fileType === "excel" || pdf.fileType === "word") && !pdf.isLocal;

      if (pdf.merged) {
        status.style.color = "#8e24aa";
        status.textContent = "Merged";
      } else if (isPlainOffice) {
        if (pdf.converted) {
          status.style.color = "#00897b";
          status.textContent = "Converted";
        } else {
          status.style.color = "#e6a100";
          status.textContent = "Pending";
        }
      } else if (isPlainPdf) {
        // Plain downloaded PDFs have no upload status — only used for merging.
        status.textContent = "";
      } else if (pdf.uploaded) {
        status.style.color = "#4caf50";
        status.textContent = "Uploaded";
      } else {
        status.style.color = "#e6a100";
        status.textContent = "Pending";
      }

      const btn = document.createElement("button");
      btn.textContent = pdf.uploaded ? "Re-upload" : "Upload";

      let browseBtn = null;
      if (pdf.fileType === "zip") {
        browseBtn = document.createElement("button");
        browseBtn.textContent = "Browse";
        browseBtn.style.background = "#555";
        browseBtn.addEventListener("click", () => openZipBrowser(pdf));
      }

      let convertBtn = null;
      if (isPlainOffice) {
        convertBtn = document.createElement("button");
        convertBtn.textContent = pdf.converted ? "Re-convert" : "Convert to PDF";
        convertBtn.style.background = "#00897b";
        convertBtn.addEventListener("click", () => convertToPdf(pdf, convertBtn));
      }

      let attachBtn = null;
      if (isPlainPdf || isPlainOffice) {
        attachBtn = document.createElement("button");
        attachBtn.textContent = pdf.attached ? "📎 Re-attach" : "📎 Attach File";
        attachBtn.title = "Manually pick this file from disk (fixes Slack/WhatsApp/etc. sources that block automatic download)";
        attachBtn.style.background = "#555";
        attachBtn.addEventListener("click", () => attachFileManually(pdf));
      }

      let openBtn = null;
      if (pdf.fileType === "pdf" && pdf.isLocal) {
        openBtn = document.createElement("button");
        openBtn.textContent = "👁 Open";
        openBtn.style.background = "#0b8043";
        openBtn.addEventListener("click", async () => {
          openBtn.disabled = true;
          openBtn.textContent = "Loading...";
          const blob = await loadBlobFromDb(pdf.id);
          openBtn.disabled = false;
          openBtn.textContent = "👁 Open";
          if (!blob) {
            statusEl.textContent = "Preview data not found. Re-merge/convert to view again.";
            return;
          }
          const url = URL.createObjectURL(blob);
          chrome.tabs.create({ url });
        });
      }

      btn.addEventListener("click", async () => {
        btn.disabled = true;
        btn.textContent = "...";
        const uploadName = pdf.renamedName || pdf.fileName;
        statusEl.textContent = "Uploading " + uploadName + "...";

        const folderData = await new Promise((resolve) => chrome.storage.local.get(["lastFolderId"], resolve));
        const folderId = folderData.lastFolderId || "";

        if (pdf.isLocal) {
          const blob = await loadBlobFromDb(pdf.id);
          if (!blob) {
            statusEl.textContent = "This file's data was not found. Please merge/convert again.";
            btn.disabled = false;
            btn.textContent = "Upload";
            return;
          }
          try {
            await uploadBlobGeneric(blob, uploadName, folderId, pdf.id);
            statusEl.textContent = "Uploaded: " + uploadName;
            btn.textContent = "Re-upload";
            btn.disabled = false;
            status.textContent = "Uploaded";
            status.style.color = "#4caf50";
            await markUploaded(pdf.id);
            bumpStatPopup("uploaded", 1);
            renderStats();
          } catch (err) {
            statusEl.textContent = "FAILED: " + (err.message || err);
            btn.textContent = "Retry";
            btn.disabled = false;
          }
          return;
        }

        chrome.runtime.sendMessage({ type: "UPLOAD_PDF", pdf, folderId }, (response) => {
          if (response && response.success) {
            statusEl.textContent = "Uploaded: " + uploadName;
            btn.textContent = "Re-upload";
            btn.disabled = false;
            status.textContent = "Uploaded";
            status.style.color = "#4caf50";
            markUploaded(pdf.id);
            renderStats();
          } else {
            statusEl.textContent = "FAILED: " + (response ? response.error : "no response");
            btn.textContent = "Retry";
            btn.disabled = false;
          }
        });
      });

      const delBtn = document.createElement("button");
      delBtn.textContent = "🗑";
      delBtn.title = "Delete";
      delBtn.style.background = "#d93025";
      delBtn.addEventListener("click", () => {
        chrome.runtime.sendMessage({ type: "DELETE_PDF", id: pdf.id }, (response) => {
          if (response && response.success) {
            renderList();
            renderStats();
          }
        });
      });

      row.appendChild(checkbox);
      row.appendChild(orderBadge);
      row.appendChild(nameInput);
      row.appendChild(status);
      if (browseBtn) {
        row.appendChild(browseBtn);
      }
      if (convertBtn) {
        row.appendChild(convertBtn);
      }
      if (attachBtn) {
        row.appendChild(attachBtn);
      }
      if (openBtn) {
        row.appendChild(openBtn);
      }
      const canUpload = pdf.fileType === "pdf" && !!pdf.isLocal;
      if (canUpload) {
        row.appendChild(btn);
      }
      row.appendChild(delBtn);
      pdfListEl.appendChild(row);
    });
    updateSelectedCount();
    renumberOrderBadges();
  });
}

renderList();

// ---------- ZIP Browser ----------
const zipPanelEl = document.getElementById("zipBrowserPanel");
const zipBreadcrumbEl = document.getElementById("zipBreadcrumb");
const zipEntriesEl = document.getElementById("zipEntries");
document.getElementById("closeZipBrowser").addEventListener("click", () => {
  zipPanelEl.style.display = "none";
});

let currentZip = null;      // loaded JSZip instance
let zipPathStack = [""];    // breadcrumb of folder prefixes inside the zip

async function openZipBrowser(pdf) {
  zipPanelEl.style.display = "block";
  zipEntriesEl.innerHTML = '<div style="font-size:12px; color:#888;">Loading zip...</div>';
  zipBreadcrumbEl.textContent = "";

  try {
    const res = await fetchSourceFilePopup(pdf.sourceUrl);
    if (!res.ok) throw new Error("Could not fetch zip: HTTP " + res.status);
    const blob = await res.blob();
    currentZip = await JSZip.loadAsync(blob);
    zipPathStack = [""];
    renderZipLevel();
  } catch (err) {
    zipEntriesEl.innerHTML = '<div style="font-size:12px; color:#d93025;">' + (err.message || err) + '</div>';
  }
}

function renderZipBreadcrumb() {
  zipBreadcrumbEl.innerHTML = "";
  zipPathStack.forEach((prefix, idx) => {
    const label = idx === 0 ? "zip root" : prefix.split("/").filter(Boolean).pop();
    const span = document.createElement("span");
    span.className = "crumb";
    span.textContent = label;
    span.addEventListener("click", () => {
      zipPathStack = zipPathStack.slice(0, idx + 1);
      renderZipLevel();
    });
    zipBreadcrumbEl.appendChild(span);
    if (idx < zipPathStack.length - 1) {
      zipBreadcrumbEl.appendChild(document.createTextNode(" / "));
    }
  });
}

function renderZipLevel() {
  renderZipBreadcrumb();
  const prefix = zipPathStack[zipPathStack.length - 1];
  const seenFolders = new Set();
  const rows = [];

  currentZip.forEach((relPath, entry) => {
    if (!relPath.startsWith(prefix)) return;
    const rest = relPath.slice(prefix.length);
    if (!rest) return;
    const slashIdx = rest.indexOf("/");

    if (slashIdx !== -1) {
      // it's inside a subfolder — show that subfolder once
      const folderName = rest.slice(0, slashIdx);
      if (!seenFolders.has(folderName)) {
        seenFolders.add(folderName);
        rows.push({ type: "folder", name: folderName, path: prefix + folderName + "/" });
      }
    } else if (!entry.dir) {
      rows.push({ type: "file", name: rest, path: relPath, entry });
    }
  });

  zipEntriesEl.innerHTML = "";
  if (rows.length === 0) {
    zipEntriesEl.innerHTML = '<div style="font-size:12px; color:#888; padding:6px;">Empty folder.</div>';
    return;
  }

  rows.forEach((row) => {
    const div = document.createElement("div");
    div.className = "folder-row";

    if (row.type === "folder") {
      div.textContent = "📁 " + row.name;
      div.addEventListener("click", () => {
        zipPathStack.push(row.path);
        renderZipLevel();
      });
    } else {
      const isPdf = row.name.toLowerCase().endsWith(".pdf");
      div.style.display = "flex";
      div.style.alignItems = "center";
      div.style.gap = "4px";
      div.style.flexWrap = "wrap";

      const icon = isPdf ? "📄 " : "📃 ";
      const nameInput = document.createElement("input");
      nameInput.type = "text";
      nameInput.value = row.name;
      nameInput.title = "Rename before upload";
      nameInput.style.flex = "1";
      nameInput.style.minWidth = "80px";
      nameInput.style.fontSize = "11px";
      nameInput.style.border = "1px solid #ccc";
      nameInput.style.borderRadius = "4px";
      nameInput.style.padding = "2px 4px";
      div.appendChild(nameInput);

      const openBtn = document.createElement("button");
      openBtn.textContent = "Open";
      openBtn.style.background = "#0b8043";
      openBtn.addEventListener("click", async (e) => {
        e.stopPropagation();
        try {
          const rawBlob = await row.entry.async("blob");
          const typedBlob = new Blob([rawBlob], { type: guessMime(row.name) });
          const url = URL.createObjectURL(typedBlob);
          chrome.tabs.create({ url });
        } catch (err) {
          statusEl.textContent = "Could not open: " + (err.message || err);
        }
      });
      div.appendChild(openBtn);

      const upBtn = document.createElement("button");
      upBtn.textContent = "Upload";
      upBtn.addEventListener("click", async (e) => {
        e.stopPropagation();
        upBtn.disabled = true;
        upBtn.textContent = "...";
        const uploadName = nameInput.value || row.name;
        statusEl.textContent = "Extracting " + uploadName + "...";
        try {
          const fileBlob = await row.entry.async("blob");
          statusEl.textContent = "Uploading " + uploadName + "...";
          const folderData = await chrome.storage.local.get(["lastFolderId"]);
          await uploadBlobGeneric(fileBlob, uploadName, folderData.lastFolderId || "");
          statusEl.textContent = "Uploaded: " + uploadName;
          upBtn.textContent = "Done";
          bumpStatPopup("uploaded", 1);
        } catch (err) {
          statusEl.textContent = "FAILED: " + (err.message || err);
          upBtn.textContent = "Retry";
          upBtn.disabled = false;
        }
      });
      div.appendChild(upBtn);
    }

    zipEntriesEl.appendChild(div);
  });
}

function getAuthTokenPopup() {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      const err = chrome.runtime.lastError;
      if (err || !token) reject(err ? err.message : "no token returned");
      else resolve(token);
    });
  });
}

function guessMime(fileName) {
  const lower = fileName.toLowerCase();
  if (lower.endsWith(".pdf")) return "application/pdf";
  if (lower.endsWith(".html") || lower.endsWith(".htm")) return "text/html";
  if (lower.endsWith(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  if (lower.endsWith(".xls")) return "application/vnd.ms-excel";
  if (lower.endsWith(".csv")) return "text/csv";
  if (lower.endsWith(".txt")) return "text/plain";
  if (lower.endsWith(".png")) return "image/png";
  if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
  return "application/octet-stream";
}

// ---------- Upload Destination (Drive vs Local Folder) ----------
let uploadDestination = "drive"; // "drive" | "local"
let localDirHandle = null;

// Persist the FileSystemDirectoryHandle across popup sessions using IndexedDB
// (chrome.storage can't hold these handles, but IndexedDB can via structured clone).
function openHandleDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("driveUploaderHandles", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("handles");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function saveDirHandle(handle) {
  const db = await openHandleDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("handles", "readwrite");
    tx.objectStore("handles").put(handle, "localFolder");
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function loadDirHandle() {
  const db = await openHandleDb();
  return new Promise((resolve) => {
    const tx = db.transaction("handles", "readonly");
    const req = tx.objectStore("handles").get("localFolder");
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => resolve(null);
  });
}

const destDriveBtn = document.getElementById("destDriveBtn");
const destLocalBtn = document.getElementById("destLocalBtn");
const driveDestPanel = document.getElementById("driveDestPanel");
const localDestPanel = document.getElementById("localDestPanel");
const selectedLocalFolderEl = document.getElementById("selectedLocalFolder");

destDriveBtn.addEventListener("click", () => {
  uploadDestination = "drive";
  destDriveBtn.style.background = "#8e24aa";
  destLocalBtn.style.background = "#555";
  driveDestPanel.style.display = "block";
  localDestPanel.style.display = "none";
});

destLocalBtn.addEventListener("click", () => {
  uploadDestination = "local";
  destLocalBtn.style.background = "#8e24aa";
  destDriveBtn.style.background = "#555";
  driveDestPanel.style.display = "none";
  localDestPanel.style.display = "block";
});

document.getElementById("chooseLocalFolderBtn").addEventListener("click", async () => {
  try {
    localDirHandle = await window.showDirectoryPicker();
    await saveDirHandle(localDirHandle);
    selectedLocalFolderEl.textContent = "Selected: " + localDirHandle.name;
    statusEl.textContent = "Local folder chosen: " + localDirHandle.name;
  } catch (err) {
    statusEl.textContent = "Folder selection cancelled or failed.";
  }
});

// Restore the previously chosen local folder on popup open, if permission
// is still granted. If Chrome needs re-confirmation, show a reconnect button
// instead of forcing a full re-pick.
(async () => {
  const handle = await loadDirHandle();
  if (!handle) return;
  try {
    const perm = await handle.queryPermission({ mode: "readwrite" });
    if (perm === "granted") {
      localDirHandle = handle;
      selectedLocalFolderEl.textContent = "Selected: " + handle.name;
    } else {
      selectedLocalFolderEl.textContent = "Folder: " + handle.name + " (needs reconnect)";
      const reconnectBtn = document.createElement("button");
      reconnectBtn.textContent = "🔄 Reconnect to " + handle.name;
      reconnectBtn.style.width = "100%";
      reconnectBtn.style.marginBottom = "10px";
      reconnectBtn.addEventListener("click", async () => {
        const newPerm = await handle.requestPermission({ mode: "readwrite" });
        if (newPerm === "granted") {
          localDirHandle = handle;
          selectedLocalFolderEl.textContent = "Selected: " + handle.name;
          reconnectBtn.remove();
          statusEl.textContent = "Reconnected to " + handle.name;
        } else {
          statusEl.textContent = "Permission denied. Choose a new folder instead.";
        }
      });
      localDestPanel.insertBefore(reconnectBtn, document.getElementById("chooseLocalFolderBtn"));
    }
  } catch (err) {
    // Handle no longer valid (folder moved/deleted) — user will need to re-pick.
  }
})();

async function writeBlobToLocalFolder(blob, fileName) {
  if (!localDirHandle) {
    throw new Error("Choose a local folder first (Upload Destination → Local Folder).");
  }
  const fileHandle = await localDirHandle.getFileHandle(fileName, { create: true });
  const writable = await fileHandle.createWritable();
  await writable.write(blob);
  await writable.close();
  return { success: true };
}

async function uploadBlobToDrive(blob, fileName, folderId, entryId) {
  // Convert to raw bytes and hand off to the background service worker —
  // that way the actual network upload keeps running even if this popup
  // closes (e.g. user clicks elsewhere) mid-upload.
  const arrayBuffer = await blob.arrayBuffer();
  const mimeType = guessMime(fileName);

  const response = await new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { type: "UPLOAD_BLOB", arrayBuffer, fileName, mimeType, folderId, entryId },
      (res) => resolve(res)
    );
  });

  if (!response || !response.success) {
    throw new Error(response ? response.error : "No response from background (upload may still be running)");
  }
  return response.result;
}

// Routes to Drive or Local Folder depending on the current toggle.
async function uploadBlobGeneric(blob, fileName, folderId, entryId) {
  if (uploadDestination === "local") {
    return writeBlobToLocalFolder(blob, fileName);
  }
  return uploadBlobToDrive(blob, fileName, folderId, entryId);
}

// ---------- Bulk actions ----------
document.getElementById("selectAllBox").addEventListener("change", (e) => {
  document.querySelectorAll(".bulk-check").forEach((cb) => {
    cb.checked = e.target.checked;
    const id = cb.dataset.id;
    if (e.target.checked) {
      selectionCounter += 1;
      selectionSeqMap[id] = selectionCounter;
    } else {
      delete selectionSeqMap[id];
    }
  });
  updateSelectedCount();
  renumberOrderBadges();
});

function getSelectedIds() {
  return Object.keys(selectionSeqMap);
}

function updateSelectedCount() {
  const countEl = document.getElementById("selectedCount");
  if (countEl) {
    countEl.textContent = getSelectedIds().length + " selected";
  }
}

function renumberOrderBadges() {
  const checked = Array.from(document.querySelectorAll(".bulk-check:checked"))
    .map((cb) => ({ cb, id: cb.dataset.id, seq: selectionSeqMap[cb.dataset.id] || 0 }))
    .sort((a, b) => a.seq - b.seq);

  // Hide all badges first
  document.querySelectorAll(".order-badge").forEach((b) => { b.style.display = "none"; });

  checked.forEach((item, idx) => {
    const badge = item.cb.parentElement.querySelector(".order-badge");
    if (badge) {
      badge.textContent = idx + 1;
      badge.style.display = "flex";
    }
  });
}

document.getElementById("bulkUploadBtn").addEventListener("click", async () => {
  const ids = getSelectedIds();
  if (ids.length === 0) {
    statusEl.textContent = "No files selected.";
    return;
  }
  const bulkBtn = document.getElementById("bulkUploadBtn");
  bulkBtn.disabled = true;

  chrome.storage.session.get(["recentPdfs"], async (data) => {
    const all = data.recentPdfs || [];
    const targets = all.filter((p) => ids.includes(String(p.id)));
    const folderData = await chrome.storage.local.get(["lastFolderId"]);
    const folderId = folderData.lastFolderId || "";

    let successCount = 0;
    const failed = [];

    for (let i = 0; i < targets.length; i++) {
      const pdf = targets[i];
      const label = pdf.renamedName || pdf.fileName;
      statusEl.textContent = `Uploading (${i + 1}/${targets.length}): ${label}...`;

      // eslint-disable-next-line no-await-in-loop
      let result;
      if (pdf.isLocal) {
        const blob = await loadBlobFromDb(pdf.id);
        if (!blob) {
          result = { success: false, error: "file data not found — please re-merge/convert" };
        } else {
          try {
            await uploadBlobGeneric(blob, label, folderId, pdf.id);
            result = { success: true };
          } catch (err) {
            result = { success: false, error: err.message || String(err) };
          }
        }
      } else {
        result = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: "UPLOAD_PDF", pdf, folderId }, (response) => {
            resolve(response);
          });
        });
      }

      if (result && result.success) {
        successCount += 1;
        await markUploaded(pdf.id);
      } else {
        failed.push({ name: label, error: result ? result.error : "no response" });
      }
    }

    if (failed.length === 0) {
      statusEl.textContent = `Bulk upload complete: ${successCount}/${targets.length} uploaded successfully.`;
    } else {
      statusEl.textContent =
        `Bulk upload: ${successCount}/${targets.length} succeeded. Failed: ` +
        failed.map((f) => `${f.name} (${f.error})`).join("; ");
    }
    bulkBtn.disabled = false;
    renderList();
    renderStats();
  });
});

document.getElementById("bulkDeleteBtn").addEventListener("click", async () => {
  const ids = getSelectedIds();
  if (ids.length === 0) {
    statusEl.textContent = "No files selected.";
    return;
  }
  const bulkBtn = document.getElementById("bulkDeleteBtn");
  bulkBtn.disabled = true;

  let successCount = 0;
  const failed = [];

  for (let i = 0; i < ids.length; i++) {
    const id = ids[i];
    statusEl.textContent = `Deleting (${i + 1}/${ids.length})...`;
    // eslint-disable-next-line no-await-in-loop
    const result = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "DELETE_PDF", id }, (response) => resolve(response));
    });
    if (result && result.success) {
      successCount += 1;
    } else {
      failed.push(id);
    }
  }

  if (failed.length === 0) {
    statusEl.textContent = `Deleted ${successCount} file(s).`;
  } else {
    statusEl.textContent = `Deleted ${successCount}/${ids.length}. ${failed.length} failed.`;
  }
  bulkBtn.disabled = false;
  renderList();
  renderStats();
});

// ---------- Merge Selected PDFs ----------
document.getElementById("mergePdfBtn").addEventListener("click", async () => {
  const ids = getSelectedIds();
  if (ids.length < 2) {
    statusEl.textContent = "Select at least 2 PDFs to merge.";
    return;
  }

  const mergeBtn = document.getElementById("mergePdfBtn");
  mergeBtn.disabled = true;

  try {
    const data = await new Promise((resolve) => chrome.storage.session.get(["recentPdfs"], resolve));
    const all = data.recentPdfs || [];
    // Merge in the exact order the checkboxes were clicked by the user,
    // using each id's recorded sequence number.
    const orderedIds = ids
      .slice()
      .sort((a, b) => (selectionSeqMap[a] || 0) - (selectionSeqMap[b] || 0));
    const targets = orderedIds
      .map((id) => all.find((p) => String(p.id) === id))
      .filter(Boolean);

    const mergedPdf = await PDFLib.PDFDocument.create();

    statusEl.textContent = "Merge order: " + targets.map((t) => t.fileName).join(" → ");
    await new Promise((r) => setTimeout(r, 800)); // brief pause so the order is visible

    for (let i = 0; i < targets.length; i++) {
      const pdf = targets[i];
      statusEl.textContent = `Fetching (${i + 1}/${targets.length}): ${pdf.fileName}...`;
      let bytes;
      if (pdf.isLocal) {
        const blob = await loadBlobFromDb(pdf.id);
        if (!blob) throw new Error(`Data for ${pdf.fileName} not found — re-convert/re-merge it first.`);
        bytes = await blob.arrayBuffer();
      } else {
        try {
          bytes = await getSourceBytes(pdf);
        } catch (err) {
          throw new Error(
            `${err.message} — if this file is from Slack/WhatsApp/etc., click "📎 Attach File" on it first, then try merging again.`
          );
        }
      }
      const srcDoc = await PDFLib.PDFDocument.load(bytes);
      const copiedPages = await mergedPdf.copyPages(srcDoc, srcDoc.getPageIndices());
      copiedPages.forEach((page) => mergedPdf.addPage(page));
    }

    statusEl.textContent = "Building merged PDF...";
    const mergedBytes = await mergedPdf.save();
    const mergedBlob = new Blob([mergedBytes], { type: "application/pdf" });

    const mergedName = `merged_${Date.now()}.pdf`;
    const newId = "merged-" + Date.now();
    await saveBlobToDb(newId, mergedBlob);

    // Add the merged file as a new entry so it can be uploaded/renamed/deleted
    // through the normal PDF list, just like any downloaded file.
    const newEntry = {
      id: newId,
      fileName: mergedName,
      fileType: "pdf",
      sourceUrl: "", // handled via IndexedDB blob storage instead
      isLocal: true,
      time: Date.now()
    };

    // Mark the source PDFs used in this merge so the PDF tab shows them
    // as "Merged" instead of the normal Pending/Uploaded status.
    const targetIds = new Set(targets.map((t) => String(t.id)));
    const markedAll = all.map((p) =>
      targetIds.has(String(p.id)) ? { ...p, merged: true } : p
    );

    const updatedList = [newEntry, ...markedAll];
    await new Promise((resolve) => chrome.storage.session.set({ recentPdfs: updatedList }, resolve));

    statusEl.textContent = `Merged ${targets.length} PDFs into ${mergedName}. Ready to upload below.`;
    bumpStatPopup("merged", 1);
    renderList();
    renderStats();
  } catch (err) {
    statusEl.textContent = "Merge failed: " + (err.message || err);
  } finally {
    mergeBtn.disabled = false;
  }
});

// ---------- Excel / Word → PDF Conversion ----------
// The standard PDF fonts (Helvetica etc.) only support WinAnsi encoding —
// Latin-based characters. Any character outside that range (Georgian,
// Cyrillic, CJK, emoji, etc.) would crash pdf-lib, so replace those with
// "?" instead of failing the whole conversion.
// Uses Google Drive's OWN conversion engine (the same one Google Sheets /
// Google Docs use) instead of a hand-rolled renderer. This gives accurate,
// near-identical-to-original output: real fonts, colors, merged cells,
// borders, images, formatting — things a from-scratch PDF renderer can't
// reliably reproduce.
// Excel sheets often have formatting applied way beyond the real data
// (extra blank rows/columns), which makes Google Sheets treat that whole
// area as printable — producing lots of blank pages on export. Trim each
// sheet down to just the cells that actually contain data before
// converting, so the PDF only has the pages that matter.
// After Drive auto-converts an uploaded Excel file into a Google Sheet,
// trailing blank rows/columns from the original file's used range can make
// Sheets treat that empty area as printable, producing blank pages on
// export. Trim the CONVERTED Google Sheet's grid down to the real data —
// never touching the original file — so all colors/formatting stay intact.

async function convertToPdf(pdf, btnEl) {
  btnEl.disabled = true;
  btnEl.textContent = "Converting...";
  statusEl.textContent = "Converting " + pdf.fileName + " in the background (survives popup close)...";

  const response = await new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { type: "CONVERT_TO_PDF", pdf },
      (res) => resolve(res)
    );
  });

  if (response && response.success) {
    statusEl.textContent = `Converted: ${response.newName}. Check the ${pdf.fileType === "excel" ? "Excel→PDF" : "Word→PDF"} tab to upload it.`;
    btnEl.textContent = "Converted ✓";
    renderList();
    renderStats();
  } else {
    statusEl.textContent = "Conversion failed: " + (response ? response.error : "no response");
    btnEl.textContent = "Retry Convert";
    btnEl.disabled = false;
  }
}

// ---------- Manual attach (fixes Slack/WhatsApp/etc. that block automatic
// download by extensions) ----------
async function attachFileManually(pdf) {
  const picker = document.getElementById("attachFilePicker");
  picker.value = "";
  picker.onchange = async () => {
    const file = picker.files[0];
    if (!file) return;

    statusEl.textContent = "Attaching " + file.name + "...";
    await saveBlobToDb("attached-" + pdf.id, file);

    const data = await new Promise((resolve) => chrome.storage.session.get(["recentPdfs"], resolve));
    const all = data.recentPdfs || [];
    const updated = all.map((p) => (String(p.id) === String(pdf.id) ? { ...p, attached: true } : p));
    await new Promise((resolve) => chrome.storage.session.set({ recentPdfs: updated }, resolve));

    statusEl.textContent = "Attached: " + file.name + ". This file will now be used instead of re-downloading.";
    renderList();
  };
  picker.click();
}

// Returns bytes for a PDF entry, preferring a manually-attached file
// (fixes sources like Slack/WhatsApp that block automatic re-fetching)
// before falling back to the normal source URL fetch.
async function getSourceBytes(pdf) {
  const attached = await loadBlobFromDb("attached-" + pdf.id);
  if (attached) return attached.arrayBuffer();

  const res = await fetchSourceFilePopup(pdf.sourceUrl);
  if (!res.ok) throw new Error(`Could not fetch ${pdf.fileName}: HTTP ${res.status}`);
  return res.arrayBuffer();
}
