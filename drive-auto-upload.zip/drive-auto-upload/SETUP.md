# Setup Instructions

## Step 1: Load the extension
1. Open `chrome://extensions`
2. Turn on "Developer mode" (top right)
3. Click "Load unpacked" and select this folder
4. Click the extension icon in the toolbar — the popup will show your
   **Extension ID**. Copy it.

## Step 2: Create the OAuth Client (this is the step that usually goes wrong)
1. Go to https://console.cloud.google.com/apis/credentials
2. Click **Create Credentials → OAuth client ID**
3. Application type: **Chrome Extension** (NOT "Web application" — this is
   the #1 cause of getAuthToken failing)
4. Paste your Extension ID from Step 1
5. Copy the generated Client ID

## Step 3: Enable the Drive API
1. Go to https://console.cloud.google.com/apis/library/drive.googleapis.com
2. Click **Enable** (if not already enabled)

## Step 4: Configure OAuth consent screen
1. Go to https://console.cloud.google.com/apis/credentials/consent
2. If it's in "Testing" mode, scroll to **Test users** and add your own
   Google account email. Without this, login silently fails.

## Step 5: Update manifest.json
Open `manifest.json` and replace:
```
"client_id": "PASTE_YOUR_CLIENT_ID_HERE.apps.googleusercontent.com"
```
with your real client ID from Step 2.

## Step 6: Reload and test
1. Go back to `chrome://extensions`, click the reload icon on the extension
2. Click the extension icon → click **"Test Login"**
3. If it fails, the popup will show the EXACT error message from Chrome —
   send that message for further debugging.

## Note on work/managed profiles
If your Chrome is signed into a company Google Workspace account with
device management policies, an admin may need to allow third-party apps
via Google Workspace Admin Console → Security → API Controls.
