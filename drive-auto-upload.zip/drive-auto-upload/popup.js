// ---------- PIN Lock ----------
const lockScreenEl = document.getElementById("lockScreen");
const mainContentEl = document.getElementById("mainContent");
const pinInputEl = document.getElementById("pinInput");
const lockErrorEl = document.getElementById("lockError");

function checkLock() {
  chrome.storage.local.get(["appPin"], (localData) => {
    if (!localData.appPin) {
      lockScreenEl.style.display = "none";
      mainContentEl.style.display = "block";
      return;
    }
    // PIN is set — but only ask once per browser session. If already
    // unlocked this session, skip straight to the main content.
    chrome.storage.session.get(["unlocked"], (sessionData) => {
      if (sessionData.unlocked) {
        lockScreenEl.style.display = "none";
        mainContentEl.style.display = "block";
      } else {
        lockScreenEl.style.display = "flex";
        mainContentEl.style.display = "none";
        pinInputEl.focus();
      }
    });
  });
}
checkLock();

document.getElementById("unlockBtn").addEventListener("click", () => {
  chrome.storage.local.get(["appPin"], (data) => {
    if (pinInputEl.value === data.appPin) {
      chrome.storage.session.set({ unlocked: true }, () => {
        lockScreenEl.style.display = "none";
        mainContentEl.style.display = "block";
        lockErrorEl.textContent = "";
        pinInputEl.value = "";
      });
    } else {
      lockErrorEl.textContent = "Incorrect PIN. Try again.";
      pinInputEl.value = "";
    }
  });
});
pinInputEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter") document.getElementById("unlockBtn").click();
});

document.getElementById("pinSettingsBtn").addEventListener("click", () => {
  openPinSettingsPanel();
});

function openPinSettingsPanel() {
  chrome.storage.local.get(["appPin"], (data) => {
    const hasPin = !!data.appPin;
    const panel = document.createElement("div");
    panel.style.position = "fixed";
    panel.style.inset = "0";
    panel.style.background = "var(--bg)";
    panel.style.display = "flex";
    panel.style.flexDirection = "column";
    panel.style.alignItems = "center";
    panel.style.justifyContent = "center";
    panel.style.padding = "20px";
    panel.style.zIndex = "1000";

    panel.innerHTML = `
      <h3>${hasPin ? "Change / Remove PIN" : "Set a PIN"}</h3>
      <input type="password" id="pinSetInput" placeholder="${hasPin ? "New PIN (leave blank to remove)" : "Enter new PIN"}" style="width:100%; padding:8px; margin-bottom:10px; border-radius:6px;">
      <button id="pinSaveBtn" style="width:100%; margin-bottom:6px;">Save</button>
      <button id="pinCancelBtn" style="width:100%; background:#777;">Cancel</button>
      <div id="pinSetMsg" style="font-size:11px; margin-top:8px;"></div>
    `;
    document.body.appendChild(panel);

    const msgEl = panel.querySelector("#pinSetMsg");
    panel.querySelector("#pinCancelBtn").addEventListener("click", () => panel.remove());
    panel.querySelector("#pinSaveBtn").addEventListener("click", () => {
      const val = panel.querySelector("#pinSetInput").value;
      if (val === "" && hasPin) {
        chrome.storage.local.remove("appPin", () => {
          msgEl.textContent = "PIN lock removed.";
          setTimeout(() => panel.remove(), 800);
        });
      } else if (val === "") {
        msgEl.textContent = "Enter a PIN, or cancel.";
      } else {
        chrome.storage.local.set({ appPin: val }, () => {
          msgEl.textContent = "PIN saved.";
          setTimeout(() => panel.remove(), 800);
        });
      }
    });
  });
}

// ---------- Dark mode ----------
const darkToggleBtn = document.getElementById("darkModeToggle");
chrome.storage.local.get(["darkMode"], (data) => {
  if (data.darkMode) {
    document.body.classList.add("dark-mode");
    darkToggleBtn.textContent = "☀️";
  }
});
darkToggleBtn.addEventListener("click", () => {
  const isDark = document.body.classList.toggle("dark-mode");
  darkToggleBtn.textContent = isDark ? "☀️" : "🌙";
  chrome.storage.local.set({ darkMode: isDark });
});

document.getElementById("extId").textContent = chrome.runtime.id;

// Some hosts reject requests when credentials are included with a
// wildcard CORS policy; others require credentials to authorize the
// download at all. Try both so either case works — this fixes blank
// merged PDFs and failed ZIP loads caused by silently-wrong fetches.
async function fetchSourceFilePopup(url) {
  try {
    const res = await fetch(url, { credentials: "include" });
    if (res.ok) return res;
  } catch (err) {
    console.warn("fetch with credentials failed, retrying without:", err.message || err);
  }
  return fetch(url, { credentials: "omit" });
}

// In-memory store for blobs generated locally (e.g. merged PDFs) that can't
// be fetched by the background service worker since blob: URLs are scoped
// to the document that created them.
// Persistent blob storage for merged PDFs, so "Open" and "Upload" keep
// working even after the popup is closed and reopened (unlike a plain
// in-memory object, which resets every time this script re-runs).
function openBlobDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("driveUploaderBlobs", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("blobs");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function saveBlobToDb(id, blob) {
  const db = await openBlobDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("blobs", "readwrite");
    tx.objectStore("blobs").put(blob, id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function loadBlobFromDb(id) {
  const db = await openBlobDb();
  return new Promise((resolve) => {
    const tx = db.transaction("blobs", "readonly");
    const req = tx.objectStore("blobs").get(id);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => resolve(null);
  });
}

// Tracks the order in which checkboxes were clicked (not list order), so
// merges follow the order the user selected files in. Maps id -> sequence
// number at the moment it was checked (higher = checked later).
const selectionSeqMap = {};
let selectionCounter = 0;

const statusEl = document.getElementById("status");
const pdfListEl = document.getElementById("pdfList");
const folderBrowserEl = document.getElementById("folderBrowser");
const breadcrumbEl = document.getElementById("breadcrumb");
const selectedFolderEl = document.getElementById("selectedFolder");

document.getElementById("testAuth").addEventListener("click", () => {
  statusEl.textContent = "Requesting token...";
  chrome.identity.getAuthToken({ interactive: true }, (token) => {
    const err = chrome.runtime.lastError;
    if (err || !token) {
      statusEl.textContent = "FAILED:\n" + (err ? err.message : "no token returned");
    } else {
      statusEl.textContent = "SUCCESS! Token received.\nLogin is working correctly.";
    }
  });
});

// ---------- Folder browser ----------
// path is an array of {id, name} representing the breadcrumb trail.
// path[0] is always the virtual root { id: null, name: "My Drive" }.
let path = [{ id: null, name: "My Drive" }];
let currentFolders = [];

function renderBreadcrumb() {
  breadcrumbEl.innerHTML = "";
  path.forEach((crumb, idx) => {
    const span = document.createElement("span");
    span.className = "crumb";
    span.textContent = crumb.name;
    span.addEventListener("click", () => {
      path = path.slice(0, idx + 1);
      savePathToStorage();
      loadFolderLevel(crumb.id);
    });
    breadcrumbEl.appendChild(span);
    if (idx < path.length - 1) {
      breadcrumbEl.appendChild(document.createTextNode(" / "));
    }
  });
}

function savePathToStorage() {
  chrome.storage.local.set({ lastBrowsePath: path });
}

function renderFolderList() {
  folderBrowserEl.innerHTML = "";
  if (currentFolders.length === 0) {
    folderBrowserEl.innerHTML = '<div class="folder-row" style="color:#888; cursor:default;">No subfolders here.</div>';
    return;
  }
  currentFolders.forEach((folder) => {
    const row = document.createElement("div");
    row.className = "folder-row";
    row.textContent = "📁 " + folder.name;
    row.addEventListener("click", () => {
      path.push({ id: folder.id, name: folder.name });
      savePathToStorage();
      loadFolderLevel(folder.id);
    });
    folderBrowserEl.appendChild(row);
  });
}

function loadFolderLevel(parentId) {
  statusEl.textContent = "Loading folders...";
  chrome.runtime.sendMessage({ type: "LIST_FOLDERS", parentId }, (response) => {
    if (response && response.success) {
      currentFolders = response.folders;
      renderBreadcrumb();
      renderFolderList();
      statusEl.textContent = "";
    } else {
      statusEl.textContent = "FAILED to load folders: " + (response ? response.error : "no response");
    }
  });
}

document.getElementById("selectHereBtn").addEventListener("click", () => {
  const current = path[path.length - 1];
  const trail = path
    .slice(1) // drop the virtual "My Drive" root label
    .map((p) => p.name);
  const lastThree = trail.slice(-3);
  const displayPath = lastThree.length > 0 ? lastThree.join(" > ") : "My Drive (root)";

  chrome.storage.local.set({ lastFolderId: current.id, lastFolderName: displayPath });
  selectedFolderEl.textContent = "Selected: " + displayPath;
  statusEl.textContent = "Folder selected: " + displayPath;
});

// Restore last selection + resume browsing from wherever we left off
chrome.storage.local.get(["lastFolderName", "lastBrowsePath"], (data) => {
  if (data.lastFolderName) {
    selectedFolderEl.textContent = "Selected: " + data.lastFolderName;
  }
  if (data.lastBrowsePath && data.lastBrowsePath.length > 0) {
    path = data.lastBrowsePath;
    loadFolderLevel(path[path.length - 1].id);
  } else {
    loadFolderLevel(null);
  }
});

// ---------- Recent PDFs ----------
// ---------- Recent Files (tabbed by type) ----------
const tabsEl = document.getElementById("tabs");
const TABS = [
  { key: "pdf", label: "📄 PDF" },
  { key: "merged", label: "🔗 Merge PDFs" },
  { key: "excel", label: "📊 Excel" },
  { key: "zip", label: "🗜 ZIP" }
];
let activeTab = "pdf";

function renderTabs() {
  tabsEl.innerHTML = "";
  TABS.forEach((tab) => {
    const btn = document.createElement("button");
    btn.className = "tab-btn" + (tab.key === activeTab ? " active" : "");
    btn.textContent = tab.label;
    btn.addEventListener("click", () => {
      activeTab = tab.key;
      viewMode = "tabs";
      statFilter = null;
      filterBannerEl.style.display = "none";
      tabsEl.style.display = "flex";
      renderTabs();
      renderList();
    });
    tabsEl.appendChild(btn);
  });
  const mergeBtn = document.getElementById("mergePdfBtn");
  if (mergeBtn) {
    mergeBtn.style.display = activeTab === "pdf" ? "block" : "none";
  }
}
renderTabs();

// ---------- Stats bar (clickable to filter) ----------
const statsBarEl = document.getElementById("statsBar");
const searchBoxEl = document.getElementById("searchBox");
const filterBannerEl = document.getElementById("filterBanner");
const filterBannerTextEl = document.getElementById("filterBannerText");

// viewMode: "tabs" (normal PDF/Excel/ZIP tabs) or "stat" (filtered by a stat)
let viewMode = "tabs";
let statFilter = null; // "downloaded" | "uploaded" | "pending" | "deleted"

function bumpStatPopup(key, delta) {
  chrome.storage.session.get(["stats"], (data) => {
    const stats = data.stats || { downloaded: 0, uploaded: 0, deleted: 0 };
    stats[key] = (stats[key] || 0) + delta;
    chrome.storage.session.set({ stats }, renderStats);
  });
}

function renderStats() {
  chrome.storage.session.get(["stats", "recentPdfs", "deletedPdfs"], (data) => {
    const stats = data.stats || { downloaded: 0, uploaded: 0, deleted: 0 };
    const all = data.recentPdfs || [];
    const deleted = data.deletedPdfs || [];
    const pending = all.filter((p) => !p.uploaded).length;
    const mergedCount = all.filter((p) => p.fileType === "pdf" && p.isLocal).length;

    const items = [
      { key: "downloaded", label: "Downloaded", value: stats.downloaded || 0, color: "#1a73e8" },
      { key: "merged", label: "Merge PDFs", value: mergedCount, color: "#8e24aa" },
      { key: "uploaded", label: "Uploaded", value: stats.uploaded || 0, color: "#4caf50" },
      { key: "pending", label: "Pending", value: pending, color: "#e6a100" },
      { key: "deleted", label: "Deleted", value: deleted.length, color: "#d93025" }
    ];

    statsBarEl.innerHTML = "";
    items.forEach((item) => {
      const pill = document.createElement("div");
      pill.className = "stat-pill";
      pill.innerHTML = `<span class="stat-num" style="color:${item.color}">${item.value}</span>${item.label}`;
      pill.addEventListener("click", () => {
        viewMode = "stat";
        statFilter = item.key;
        filterBannerTextEl.textContent = "Showing: " + item.label + " files";
        filterBannerEl.style.display = "flex";
        tabsEl.style.display = "none";
        renderList();
      });
      statsBarEl.appendChild(pill);
    });
  });
}
renderStats();

document.getElementById("clearFilterBtn").addEventListener("click", () => {
  viewMode = "tabs";
  statFilter = null;
  filterBannerEl.style.display = "none";
  tabsEl.style.display = "flex";
  renderList();
});

searchBoxEl.addEventListener("input", () => renderList());

function renameFile(id, newName) {
  chrome.storage.session.get(["recentPdfs"], (data) => {
    const pdfs = data.recentPdfs || [];
    const updated = pdfs.map((p) => (String(p.id) === String(id) ? { ...p, renamedName: newName } : p));
    chrome.storage.session.set({ recentPdfs: updated }, () => {
      statusEl.textContent = "Renamed to: " + newName;
      renderList();
    });
  });
}

function markUploaded(id) {
  return new Promise((resolve) => {
    chrome.storage.session.get(["recentPdfs"], (data) => {
      const pdfs = data.recentPdfs || [];
      const updated = pdfs.map((p) => (String(p.id) === String(id) ? { ...p, uploaded: true } : p));
      chrome.storage.session.set({ recentPdfs: updated }, resolve);
    });
  });
}

function renderList() {
  const keys = ["recentPdfs", "deletedPdfs"];
  chrome.storage.session.get(keys, (data) => {
    const all = data.recentPdfs || [];
    const deletedAll = data.deletedPdfs || [];
    const query = searchBoxEl.value.trim().toLowerCase();
    pdfListEl.innerHTML = "";
    updateSelectedCount();

    let source;
    let isDeletedView = false;

    if (viewMode === "stat") {
      if (statFilter === "deleted") {
        source = deletedAll;
        isDeletedView = true;
      } else if (statFilter === "merged") {
        source = all.filter((p) => p.fileType === "pdf" && p.isLocal);
      } else if (statFilter === "uploaded") {
        source = all.filter((p) => p.uploaded);
      } else if (statFilter === "pending") {
        source = all.filter((p) => !p.uploaded);
      } else {
        source = all; // "downloaded" = everything currently tracked
      }
    } else {
      if (activeTab === "pdf") {
        source = all.filter((p) => p.fileType === "pdf" && !p.isLocal);
      } else if (activeTab === "merged") {
        source = all.filter((p) => p.fileType === "pdf" && p.isLocal);
      } else {
        source = all.filter((p) => p.fileType === activeTab);
      }
    }

    if (query) {
      source = source.filter((p) =>
        (p.renamedName || p.fileName || "").toLowerCase().includes(query)
      );
    }

    if (source.length === 0) {
      pdfListEl.innerHTML = '<div class="empty">No files match.</div>';
      return;
    }

    if (isDeletedView) {
      source.forEach((pdf) => {
        const row = document.createElement("div");
        row.className = "pdf-item";
        row.style.flexWrap = "wrap";

        const name = document.createElement("div");
        name.style.flex = "1";
        name.style.fontSize = "11px";
        name.textContent = pdf.renamedName || pdf.fileName;

        const status = document.createElement("span");
        status.style.fontSize = "10px";
        status.style.marginRight = "6px";
        status.style.fontWeight = "600";
        status.style.color = pdf.uploaded ? "#4caf50" : "#e6a100";
        status.textContent = "Was: " + (pdf.uploaded ? "Uploaded" : "Pending");

        const restoreBtn = document.createElement("button");
        restoreBtn.textContent = "♻ Restore";
        restoreBtn.style.background = "#0b8043";
        restoreBtn.addEventListener("click", () => {
          chrome.runtime.sendMessage({ type: "RESTORE_PDF", id: pdf.id }, (response) => {
            if (response && response.success) {
              statusEl.textContent = "Restored: " + (pdf.renamedName || pdf.fileName);
              renderList();
              renderStats();
            } else {
              statusEl.textContent = "Restore failed: " + (response ? response.error : "unknown");
            }
          });
        });

        row.appendChild(name);
        row.appendChild(status);
        row.appendChild(restoreBtn);
        pdfListEl.appendChild(row);
      });
      return;
    }

    source.forEach((pdf) => {
      const row = document.createElement("div");
      row.className = "pdf-item";
      row.style.flexWrap = "wrap";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.className = "bulk-check";
      checkbox.dataset.id = pdf.id;

      const orderBadge = document.createElement("span");
      orderBadge.className = "order-badge";
      orderBadge.style.fontSize = "10px";
      orderBadge.style.fontWeight = "700";
      orderBadge.style.color = "white";
      orderBadge.style.background = "#1a73e8";
      orderBadge.style.borderRadius = "50%";
      orderBadge.style.width = "16px";
      orderBadge.style.height = "16px";
      orderBadge.style.display = "none";
      orderBadge.style.alignItems = "center";
      orderBadge.style.justifyContent = "center";
      orderBadge.style.marginRight = "2px";

      checkbox.addEventListener("change", () => {
        const id = String(pdf.id);
        if (checkbox.checked) {
          selectionCounter += 1;
          selectionSeqMap[id] = selectionCounter;
        } else {
          delete selectionSeqMap[id];
        }
        updateSelectedCount();
        renumberOrderBadges();
      });

      const nameInput = document.createElement("input");
      nameInput.type = "text";
      nameInput.value = pdf.renamedName || pdf.fileName;
      nameInput.title = "Rename before upload";
      nameInput.style.flex = "1";
      nameInput.style.minWidth = "90px";
      nameInput.style.fontSize = "11px";
      nameInput.style.border = "1px solid #ccc";
      nameInput.style.borderRadius = "4px";
      nameInput.style.padding = "3px 5px";
      nameInput.addEventListener("change", () => {
        renameFile(pdf.id, nameInput.value);
      });

      const status = document.createElement("span");
      status.style.fontSize = "10px";
      status.style.marginRight = "6px";
      status.style.fontWeight = "600";
      if (pdf.merged) {
        status.style.color = "#8e24aa";
        status.textContent = "Merged";
      } else if (pdf.uploaded) {
        status.style.color = "#4caf50";
        status.textContent = "Uploaded";
      } else {
        status.style.color = "#e6a100";
        status.textContent = "Pending";
      }

      const btn = document.createElement("button");
      btn.textContent = pdf.uploaded ? "Re-upload" : "Upload";

      let browseBtn = null;
      if (pdf.fileType === "zip") {
        browseBtn = document.createElement("button");
        browseBtn.textContent = "Browse";
        browseBtn.style.background = "#555";
        browseBtn.addEventListener("click", () => openZipBrowser(pdf));
      }

      let openBtn = null;
      if (pdf.fileType === "pdf" && pdf.isLocal) {
        openBtn = document.createElement("button");
        openBtn.textContent = "👁 Open";
        openBtn.style.background = "#0b8043";
        openBtn.addEventListener("click", async () => {
          openBtn.disabled = true;
          openBtn.textContent = "Loading...";
          const blob = await loadBlobFromDb(pdf.id);
          openBtn.disabled = false;
          openBtn.textContent = "👁 Open";
          if (!blob) {
            statusEl.textContent = "Preview data not found. Re-merge to view again.";
            return;
          }
          const url = URL.createObjectURL(blob);
          chrome.tabs.create({ url });
        });
      }

      btn.addEventListener("click", async () => {
        btn.disabled = true;
        btn.textContent = "...";
        // Read the live text box value directly instead of pdf.renamedName —
        // guarantees we use whatever the user typed even if they click
        // Upload before the input's "change" event has fired.
        const uploadName = nameInput.value.trim() || pdf.fileName;
        if (uploadName !== (pdf.renamedName || pdf.fileName)) {
          renameFile(pdf.id, uploadName);
        }
        statusEl.textContent = "Uploading " + uploadName + "...";

        const folderData = await new Promise((resolve) => chrome.storage.local.get(["lastFolderId"], resolve));
        const folderId = folderData.lastFolderId || "";

        if (pdf.isLocal) {
          const blob = await loadBlobFromDb(pdf.id);
          if (!blob) {
            statusEl.textContent = "This merged file's data was not found. Please merge again.";
            btn.disabled = false;
            btn.textContent = "Upload";
            return;
          }
          try {
            await uploadBlobToDrive(blob, uploadName, folderId, pdf.id);
            statusEl.textContent = "Uploaded: " + uploadName;
            btn.textContent = "Re-upload";
            btn.disabled = false;
            status.textContent = "Uploaded";
            status.style.color = "#4caf50";
            await markUploaded(pdf.id);
            bumpStatPopup("uploaded", 1);
            renderStats();
          } catch (err) {
            statusEl.textContent = "FAILED: " + (err.message || err);
            btn.textContent = "Retry";
            btn.disabled = false;
          }
          return;
        }

        chrome.runtime.sendMessage({ type: "UPLOAD_PDF", pdf: { ...pdf, renamedName: uploadName }, folderId }, (response) => {
          if (response && response.success) {
            statusEl.textContent = "Uploaded: " + uploadName;
            btn.textContent = "Re-upload";
            btn.disabled = false;
            status.textContent = "Uploaded";
            status.style.color = "#4caf50";
            markUploaded(pdf.id);
            renderStats();
          } else {
            statusEl.textContent = "FAILED: " + (response ? response.error : "no response");
            btn.textContent = "Retry";
            btn.disabled = false;
          }
        });
      });

      const delBtn = document.createElement("button");
      delBtn.textContent = "🗑";
      delBtn.title = "Delete";
      delBtn.style.background = "#d93025";
      delBtn.addEventListener("click", () => {
        chrome.runtime.sendMessage({ type: "DELETE_PDF", id: pdf.id }, (response) => {
          if (response && response.success) {
            renderList();
            renderStats();
          }
        });
      });

      row.appendChild(checkbox);
      row.appendChild(orderBadge);
      row.appendChild(nameInput);
      row.appendChild(status);
      if (browseBtn) {
        row.appendChild(browseBtn);
      }
      if (openBtn) {
        row.appendChild(openBtn);
      }
      if (pdf.fileType !== "zip") {
        row.appendChild(btn);
      }
      row.appendChild(delBtn);
      pdfListEl.appendChild(row);
    });
  });
}

renderList();

// ---------- ZIP Browser ----------
const zipPanelEl = document.getElementById("zipBrowserPanel");
const zipBreadcrumbEl = document.getElementById("zipBreadcrumb");
const zipEntriesEl = document.getElementById("zipEntries");
document.getElementById("closeZipBrowser").addEventListener("click", () => {
  zipPanelEl.style.display = "none";
});

let currentZip = null;      // loaded JSZip instance
let zipPathStack = [""];    // breadcrumb of folder prefixes inside the zip

async function openZipBrowser(pdf) {
  zipPanelEl.style.display = "block";
  zipEntriesEl.innerHTML = '<div style="font-size:12px; color:#888;">Loading zip...</div>';
  zipBreadcrumbEl.textContent = "";

  try {
    const res = await fetchSourceFilePopup(pdf.sourceUrl);
    if (!res.ok) throw new Error("Could not fetch zip: HTTP " + res.status);
    const blob = await res.blob();
    currentZip = await JSZip.loadAsync(blob);
    zipPathStack = [""];
    renderZipLevel();
  } catch (err) {
    zipEntriesEl.innerHTML = '<div style="font-size:12px; color:#d93025;">' + (err.message || err) + '</div>';
  }
}

function renderZipBreadcrumb() {
  zipBreadcrumbEl.innerHTML = "";
  zipPathStack.forEach((prefix, idx) => {
    const label = idx === 0 ? "zip root" : prefix.split("/").filter(Boolean).pop();
    const span = document.createElement("span");
    span.className = "crumb";
    span.textContent = label;
    span.addEventListener("click", () => {
      zipPathStack = zipPathStack.slice(0, idx + 1);
      renderZipLevel();
    });
    zipBreadcrumbEl.appendChild(span);
    if (idx < zipPathStack.length - 1) {
      zipBreadcrumbEl.appendChild(document.createTextNode(" / "));
    }
  });
}

function renderZipLevel() {
  renderZipBreadcrumb();
  const prefix = zipPathStack[zipPathStack.length - 1];
  const seenFolders = new Set();
  const rows = [];

  currentZip.forEach((relPath, entry) => {
    if (!relPath.startsWith(prefix)) return;
    const rest = relPath.slice(prefix.length);
    if (!rest) return;
    const slashIdx = rest.indexOf("/");

    if (slashIdx !== -1) {
      // it's inside a subfolder — show that subfolder once
      const folderName = rest.slice(0, slashIdx);
      if (!seenFolders.has(folderName)) {
        seenFolders.add(folderName);
        rows.push({ type: "folder", name: folderName, path: prefix + folderName + "/" });
      }
    } else if (!entry.dir) {
      rows.push({ type: "file", name: rest, path: relPath, entry });
    }
  });

  zipEntriesEl.innerHTML = "";
  if (rows.length === 0) {
    zipEntriesEl.innerHTML = '<div style="font-size:12px; color:#888; padding:6px;">Empty folder.</div>';
    return;
  }

  rows.forEach((row) => {
    const div = document.createElement("div");
    div.className = "folder-row";

    if (row.type === "folder") {
      div.textContent = "📁 " + row.name;
      div.addEventListener("click", () => {
        zipPathStack.push(row.path);
        renderZipLevel();
      });
    } else {
      const isPdf = row.name.toLowerCase().endsWith(".pdf");
      div.style.display = "flex";
      div.style.alignItems = "center";
      div.style.gap = "4px";
      div.style.flexWrap = "wrap";

      const icon = isPdf ? "📄 " : "📃 ";
      const nameInput = document.createElement("input");
      nameInput.type = "text";
      nameInput.value = row.name;
      nameInput.title = "Rename before upload";
      nameInput.style.flex = "1";
      nameInput.style.minWidth = "80px";
      nameInput.style.fontSize = "11px";
      nameInput.style.border = "1px solid #ccc";
      nameInput.style.borderRadius = "4px";
      nameInput.style.padding = "2px 4px";
      div.appendChild(nameInput);

      const openBtn = document.createElement("button");
      openBtn.textContent = "Open";
      openBtn.style.background = "#0b8043";
      openBtn.addEventListener("click", async (e) => {
        e.stopPropagation();
        try {
          const rawBlob = await row.entry.async("blob");
          const typedBlob = new Blob([rawBlob], { type: guessMime(row.name) });
          const url = URL.createObjectURL(typedBlob);
          chrome.tabs.create({ url });
        } catch (err) {
          statusEl.textContent = "Could not open: " + (err.message || err);
        }
      });
      div.appendChild(openBtn);

      const upBtn = document.createElement("button");
      upBtn.textContent = "Upload";
      upBtn.addEventListener("click", async (e) => {
        e.stopPropagation();
        upBtn.disabled = true;
        upBtn.textContent = "...";
        const uploadName = nameInput.value || row.name;
        statusEl.textContent = "Extracting " + uploadName + "...";
        try {
          const fileBlob = await row.entry.async("blob");
          statusEl.textContent = "Uploading " + uploadName + "...";
          const folderData = await chrome.storage.local.get(["lastFolderId"]);
          await uploadBlobToDrive(fileBlob, uploadName, folderData.lastFolderId || "");
          statusEl.textContent = "Uploaded: " + uploadName;
          upBtn.textContent = "Done";
          bumpStatPopup("uploaded", 1);
        } catch (err) {
          statusEl.textContent = "FAILED: " + (err.message || err);
          upBtn.textContent = "Retry";
          upBtn.disabled = false;
        }
      });
      div.appendChild(upBtn);
    }

    zipEntriesEl.appendChild(div);
  });
}

function getAuthTokenPopup() {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      const err = chrome.runtime.lastError;
      if (err || !token) reject(err ? err.message : "no token returned");
      else resolve(token);
    });
  });
}

function guessMime(fileName) {
  const lower = fileName.toLowerCase();
  if (lower.endsWith(".pdf")) return "application/pdf";
  if (lower.endsWith(".html") || lower.endsWith(".htm")) return "text/html";
  if (lower.endsWith(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  if (lower.endsWith(".xls")) return "application/vnd.ms-excel";
  if (lower.endsWith(".csv")) return "text/csv";
  if (lower.endsWith(".txt")) return "text/plain";
  if (lower.endsWith(".png")) return "image/png";
  if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
  return "application/octet-stream";
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunkSize = 0x8000; // avoid call-stack overflow on large files
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

async function uploadBlobToDrive(blob, fileName, folderId, entryId) {
  // Convert to base64 and hand off to the background service worker — that
  // way the actual network upload keeps running even if this popup closes
  // (e.g. user clicks elsewhere) mid-upload. Base64 (not raw ArrayBuffer)
  // is used because chrome.runtime.sendMessage can silently corrupt raw
  // ArrayBuffers into "[object Object]" on the receiving end.
  const arrayBuffer = await blob.arrayBuffer();
  const base64Data = arrayBufferToBase64(arrayBuffer);
  const mimeType = guessMime(fileName);

  const response = await new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { type: "UPLOAD_BLOB", base64Data, fileName, mimeType, folderId, entryId },
      (res) => resolve(res)
    );
  });

  if (!response || !response.success) {
    throw new Error(response ? response.error : "No response from background (upload may still be running)");
  }
  return response.result;
}

// ---------- Bulk actions ----------
document.getElementById("selectAllBox").addEventListener("change", (e) => {
  document.querySelectorAll(".bulk-check").forEach((cb) => {
    cb.checked = e.target.checked;
    const id = cb.dataset.id;
    if (e.target.checked) {
      selectionCounter += 1;
      selectionSeqMap[id] = selectionCounter;
    } else {
      delete selectionSeqMap[id];
    }
  });
  updateSelectedCount();
  renumberOrderBadges();
});

function getSelectedIds() {
  return Array.from(document.querySelectorAll(".bulk-check:checked")).map((cb) => cb.dataset.id);
}

function updateSelectedCount() {
  const countEl = document.getElementById("selectedCount");
  if (countEl) {
    countEl.textContent = getSelectedIds().length + " selected";
  }
}

function renumberOrderBadges() {
  const checked = Array.from(document.querySelectorAll(".bulk-check:checked"))
    .map((cb) => ({ cb, id: cb.dataset.id, seq: selectionSeqMap[cb.dataset.id] || 0 }))
    .sort((a, b) => a.seq - b.seq);

  // Hide all badges first
  document.querySelectorAll(".order-badge").forEach((b) => { b.style.display = "none"; });

  checked.forEach((item, idx) => {
    const badge = item.cb.parentElement.querySelector(".order-badge");
    if (badge) {
      badge.textContent = idx + 1;
      badge.style.display = "flex";
    }
  });
}

document.getElementById("bulkUploadBtn").addEventListener("click", async () => {
  const ids = getSelectedIds();
  if (ids.length === 0) {
    statusEl.textContent = "No files selected.";
    return;
  }
  const bulkBtn = document.getElementById("bulkUploadBtn");
  bulkBtn.disabled = true;

  chrome.storage.session.get(["recentPdfs"], async (data) => {
    const all = data.recentPdfs || [];
    const targets = all.filter((p) => ids.includes(String(p.id)));
    const folderData = await chrome.storage.local.get(["lastFolderId"]);
    const folderId = folderData.lastFolderId || "";

    let successCount = 0;
    const failed = [];

    for (let i = 0; i < targets.length; i++) {
      const pdf = targets[i];
      const label = pdf.renamedName || pdf.fileName;
      statusEl.textContent = `Uploading (${i + 1}/${targets.length}): ${label}...`;

      // eslint-disable-next-line no-await-in-loop
      let result;
      if (pdf.isLocal) {
        const blob = await loadBlobFromDb(pdf.id);
        if (!blob) {
          result = { success: false, error: "merged file data not found — please re-merge" };
        } else {
          try {
            await uploadBlobToDrive(blob, label, folderId, pdf.id);
            result = { success: true };
          } catch (err) {
            result = { success: false, error: err.message || String(err) };
          }
        }
      } else {
        result = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: "UPLOAD_PDF", pdf, folderId }, (response) => {
            resolve(response);
          });
        });
      }

      if (result && result.success) {
        successCount += 1;
        await markUploaded(pdf.id);
      } else {
        failed.push({ name: label, error: result ? result.error : "no response" });
      }
    }

    if (failed.length === 0) {
      statusEl.textContent = `Bulk upload complete: ${successCount}/${targets.length} uploaded successfully.`;
    } else {
      statusEl.textContent =
        `Bulk upload: ${successCount}/${targets.length} succeeded. Failed: ` +
        failed.map((f) => `${f.name} (${f.error})`).join("; ");
    }
    bulkBtn.disabled = false;
    renderList();
    renderStats();
  });
});

document.getElementById("bulkDeleteBtn").addEventListener("click", async () => {
  const ids = getSelectedIds();
  if (ids.length === 0) {
    statusEl.textContent = "No files selected.";
    return;
  }
  const bulkBtn = document.getElementById("bulkDeleteBtn");
  bulkBtn.disabled = true;

  let successCount = 0;
  const failed = [];

  for (let i = 0; i < ids.length; i++) {
    const id = ids[i];
    statusEl.textContent = `Deleting (${i + 1}/${ids.length})...`;
    // eslint-disable-next-line no-await-in-loop
    const result = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "DELETE_PDF", id }, (response) => resolve(response));
    });
    if (result && result.success) {
      successCount += 1;
    } else {
      failed.push(id);
    }
  }

  if (failed.length === 0) {
    statusEl.textContent = `Deleted ${successCount} file(s).`;
  } else {
    statusEl.textContent = `Deleted ${successCount}/${ids.length}. ${failed.length} failed.`;
  }
  bulkBtn.disabled = false;
  renderList();
  renderStats();
});

// ---------- Merge Selected PDFs ----------
document.getElementById("mergePdfBtn").addEventListener("click", async () => {
  const ids = getSelectedIds();
  if (ids.length < 2) {
    statusEl.textContent = "Select at least 2 PDFs to merge.";
    return;
  }

  const mergeBtn = document.getElementById("mergePdfBtn");
  mergeBtn.disabled = true;

  try {
    const data = await new Promise((resolve) => chrome.storage.session.get(["recentPdfs"], resolve));
    const all = data.recentPdfs || [];
    // Merge in the exact order the checkboxes were clicked by the user,
    // using each id's recorded sequence number.
    const orderedIds = ids
      .slice()
      .sort((a, b) => (selectionSeqMap[a] || 0) - (selectionSeqMap[b] || 0));
    const targets = orderedIds
      .map((id) => all.find((p) => String(p.id) === id))
      .filter(Boolean);

    const mergedPdf = await PDFLib.PDFDocument.create();

    statusEl.textContent = "Merge order: " + targets.map((t) => t.fileName).join(" → ");
    await new Promise((r) => setTimeout(r, 800)); // brief pause so the order is visible

    for (let i = 0; i < targets.length; i++) {
      const pdf = targets[i];
      statusEl.textContent = `Fetching (${i + 1}/${targets.length}): ${pdf.fileName}...`;
      const res = await fetchSourceFilePopup(pdf.sourceUrl);
      if (!res.ok) throw new Error(`Could not fetch ${pdf.fileName}: HTTP ${res.status}`);
      const bytes = await res.arrayBuffer();
      const srcDoc = await PDFLib.PDFDocument.load(bytes);
      const copiedPages = await mergedPdf.copyPages(srcDoc, srcDoc.getPageIndices());
      copiedPages.forEach((page) => mergedPdf.addPage(page));
    }

    statusEl.textContent = "Building merged PDF...";
    const mergedBytes = await mergedPdf.save();
    const mergedBlob = new Blob([mergedBytes], { type: "application/pdf" });

    const mergedName = `merged_${Date.now()}.pdf`;
    const newId = "merged-" + Date.now();
    await saveBlobToDb(newId, mergedBlob);

    // Add the merged file as a new entry so it can be uploaded/renamed/deleted
    // through the normal PDF list, just like any downloaded file.
    const newEntry = {
      id: newId,
      fileName: mergedName,
      fileType: "pdf",
      sourceUrl: "", // handled via IndexedDB blob storage instead
      isLocal: true,
      time: Date.now()
    };

    // Mark the source PDFs used in this merge so the PDF tab shows them
    // as "Merged" instead of the normal Pending/Uploaded status.
    const targetIds = new Set(targets.map((t) => String(t.id)));
    const markedAll = all.map((p) =>
      targetIds.has(String(p.id)) ? { ...p, merged: true } : p
    );

    const updatedList = [newEntry, ...markedAll];
    await new Promise((resolve) => chrome.storage.session.set({ recentPdfs: updatedList }, resolve));

    statusEl.textContent = `Merged ${targets.length} PDFs into ${mergedName}. Ready to upload below.`;
    chrome.runtime.sendMessage({
      type: "LOG_ACTIVITY",
      action: "Merged",
      fileName: mergedName,
      fileType: "pdf",
      category: "Merge PDF"
    });
    renderList();
    renderStats();
  } catch (err) {
    statusEl.textContent = "Merge failed: " + (err.message || err);
  } finally {
    mergeBtn.disabled = false;
  }
});

// ---------- Live clock ----------
function updateClock() {
  const clockEl = document.getElementById("clockDisplay");
  if (!clockEl) return;
  const now = new Date();
  clockEl.textContent = "🕐 " + now.toLocaleDateString() + " " + now.toLocaleTimeString();
}
updateClock();
setInterval(updateClock, 1000);

// ---------- Multi-User Admin Dashboard (no CSV export) ----------
const adminSetupPanel = document.getElementById("adminSetupPanel");
const adminDashboard = document.getElementById("adminDashboard");
const adminSetupMsg = document.getElementById("adminSetupMsg");
const adminUserTableEl = document.getElementById("adminUserTable");

// Restore saved name + shared folder ID
chrome.storage.local.get(["userName", "sharedFolderId"], (data) => {
  if (data.userName) document.getElementById("userNameInput").value = data.userName;
  if (data.sharedFolderId) document.getElementById("sharedFolderIdInput").value = data.sharedFolderId;
});

document.getElementById("saveNameBtn").addEventListener("click", () => {
  const name = document.getElementById("userNameInput").value.trim();
  if (!name) {
    adminSetupMsg.textContent = "Enter your name first.";
    return;
  }
  chrome.storage.local.set({ userName: name }, () => {
    adminSetupMsg.textContent = "Name saved: " + name;
  });
});

function extractFolderId(input) {
  const match = input.match(/folders\/([a-zA-Z0-9_-]+)/);
  if (match) return match[1];
  return input.split(/[?&]/)[0].trim();
}

document.getElementById("saveFolderIdBtn").addEventListener("click", () => {
  const raw = document.getElementById("sharedFolderIdInput").value.trim();
  if (!raw) {
    adminSetupMsg.textContent = "Enter a folder ID first.";
    return;
  }
  const val = extractFolderId(raw);
  document.getElementById("sharedFolderIdInput").value = val;
  chrome.storage.local.set({ sharedFolderId: val }, () => {
    adminSetupMsg.textContent = "Shared folder ID saved: " + val;
  });
});

function showAdminDashboard() {
  adminSetupPanel.style.display = "none";
  adminDashboard.style.display = "block";
  loadAdminTable();
}

function showAdminSetup() {
  adminSetupPanel.style.display = "block";
  adminDashboard.style.display = "none";
}

document.getElementById("unlockAdminBtn").addEventListener("click", () => {
  const passphrase = document.getElementById("adminPassInput").value;
  if (!passphrase) {
    adminSetupMsg.textContent = "Enter the admin passphrase.";
    return;
  }
  adminSetupMsg.textContent = "Checking...";
  chrome.runtime.sendMessage({ type: "CHECK_ADMIN_PASSPHRASE", passphrase }, (response) => {
    if (response && response.success) {
      chrome.storage.session.set({ adminUnlocked: true }, () => {
        adminSetupMsg.textContent = response.firstSetup
          ? "You're now the founding admin for this shared log!"
          : "Admin unlocked.";
        showAdminDashboard();
      });
    } else {
      adminSetupMsg.textContent = response ? response.error : "Unlock failed.";
    }
  });
});

document.getElementById("lockAdminBtn").addEventListener("click", () => {
  chrome.storage.session.remove(["adminUnlocked"], () => {
    showAdminSetup();
  });
});

document.getElementById("refreshAdminBtn").addEventListener("click", loadAdminTable);

let adminSelectedDate = ""; // "" = all dates

document.getElementById("adminDateFilter").addEventListener("change", (e) => {
  adminSelectedDate = e.target.value;
  loadAdminTable();
});
document.getElementById("adminDateClearBtn").addEventListener("click", () => {
  adminSelectedDate = "";
  document.getElementById("adminDateFilter").value = "";
  loadAdminTable();
});

function loadAdminTable() {
  adminUserTableEl.innerHTML = "Loading...";
  const dateLabelEl = document.getElementById("adminDateLabel");
  dateLabelEl.textContent = adminSelectedDate
    ? "Showing: " + adminSelectedDate + " only"
    : "Showing: all dates (cumulative)";

  chrome.runtime.sendMessage({ type: "GET_SHARED_LOG" }, (response) => {
    if (!response || !response.success) {
      adminUserTableEl.innerHTML = "Failed to load: " + (response ? response.error : "no response");
      return;
    }
    let log = response.log || [];

    if (adminSelectedDate) {
      log = log.filter((entry) => {
        if (!entry.timestamp) return false;
        const d = new Date(entry.timestamp);
        const localDate = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
        return localDate === adminSelectedDate;
      });
    }

    const perUser = {};
    log.forEach((entry) => {
      const u = entry.user || "Unnamed User";
      if (!perUser[u]) perUser[u] = { downloaded: 0, uploaded: 0, reuploaded: 0, merged: 0, deleted: 0 };
      if (entry.action === "Downloaded") perUser[u].downloaded += 1;
      else if (entry.action === "Uploaded") perUser[u].uploaded += 1;
      else if (entry.action === "Re-uploaded") perUser[u].reuploaded += 1;
      else if (entry.action === "Merged") perUser[u].merged += 1;
      else if (entry.action === "Deleted") perUser[u].deleted += 1;
    });

    const names = Object.keys(perUser);
    if (names.length === 0) {
      adminUserTableEl.innerHTML = '<div class="empty">No activity logged' + (adminSelectedDate ? " on this date." : " yet.") + '</div>';
      return;
    }

    let html = '<table style="width:100%; border-collapse:collapse; font-size:10px;">';
    html += '<tr style="background:var(--box-bg); font-weight:600;"><td style="padding:4px;">User</td><td style="padding:4px;">Down</td><td style="padding:4px;">Up</td><td style="padding:4px;">Re-Up</td><td style="padding:4px;">Pending</td><td style="padding:4px;">Merged</td><td style="padding:4px;">Del</td></tr>';
    names.forEach((name) => {
      const s = perUser[name];
      const pending = Math.max(0, s.downloaded - s.uploaded - s.deleted);
      html += `<tr style="border-bottom:1px solid var(--border);">
        <td style="padding:4px; word-break:break-all;">${name}</td>
        <td style="padding:4px;">${s.downloaded}</td>
        <td style="padding:4px; color:#4caf50;">${s.uploaded}</td>
        <td style="padding:4px; color:#00897b;">${s.reuploaded}</td>
        <td style="padding:4px; color:#e6a100;">${pending}</td>
        <td style="padding:4px; color:#8e24aa;">${s.merged}</td>
        <td style="padding:4px; color:#d93025;">${s.deleted}</td>
      </tr>`;
    });
    html += "</table>";
    adminUserTableEl.innerHTML = html;
  });
}

// Restore admin session state on popup open
chrome.storage.session.get(["adminUnlocked"], (data) => {
  if (data.adminUnlocked) {
    showAdminDashboard();
  } else {
    showAdminSetup();
  }
});
