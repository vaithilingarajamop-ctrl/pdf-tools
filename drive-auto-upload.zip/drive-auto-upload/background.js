// Tracks the most recently downloaded PDF(s). Upload happens ONLY when the
// user clicks "Upload to Drive" in the popup — no automatic/background
// upload. This avoids look-alike "auto exfiltration" behavior that some
// corporate EDR/antivirus tools flag and kill Chrome for.

// ---------- Multi-user shared activity log (stored on Drive) ----------
// Each user sets their own display name locally — no extra Google profile
// permission needed.
async function findOrCreateSharedFile(folderId, fileName, initialContent) {
  const token = await getAuthToken();
  const query = encodeURIComponent(`name='${fileName}' and '${folderId}' in parents and trashed=false`);
  const searchRes = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name)`,
    { headers: { Authorization: "Bearer " + token } }
  );
  const searchData = await searchRes.json();
  if (searchData.files && searchData.files.length > 0) {
    return searchData.files[0].id;
  }

  const metadata = { name: fileName, parents: [folderId], mimeType: "application/json" };
  const form = new FormData();
  form.append("metadata", new Blob([JSON.stringify(metadata)], { type: "application/json" }));
  form.append("file", new Blob([JSON.stringify(initialContent)], { type: "application/json" }));
  const createRes = await fetch(
    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
    { method: "POST", headers: { Authorization: "Bearer " + token }, body: form }
  );
  const createData = await createRes.json();
  if (!createRes.ok) throw new Error(createData.error ? createData.error.message : "Could not create shared file");
  return createData.id;
}

async function readSharedFile(fileId) {
  const token = await getAuthToken();
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
    headers: { Authorization: "Bearer " + token }
  });
  if (!res.ok) throw new Error("Could not read shared file");
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    return [];
  }
}

async function updateSharedFile(fileId, content) {
  const token = await getAuthToken();
  const res = await fetch(`https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media`, {
    method: "PATCH",
    headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" },
    body: JSON.stringify(content)
  });
  if (!res.ok) throw new Error("Could not update shared file");
  return res.json();
}

async function logActivity(action, fileName, fileType, category) {
  const data = await new Promise((resolve) =>
    chrome.storage.local.get(["sharedFolderId", "userName"], resolve)
  );
  const folderId = data.sharedFolderId;
  if (!folderId) return; // shared logging not set up — silently skip
  const userName = data.userName || "Unnamed User";

  try {
    const fileId = await findOrCreateSharedFile(folderId, "shared_activity_log.json", []);
    const log = await readSharedFile(fileId);
    log.push({
      user: userName,
      action,
      fileName: fileName || "",
      fileType: fileType || "",
      category: category || "",
      timestamp: Date.now()
    });
    await updateSharedFile(fileId, log);
  } catch (err) {
    console.error("Shared activity log failed:", err.message || err);
  }
}

function updateBadge() {
  chrome.storage.session.get(["recentPdfs"], (data) => {
    const all = data.recentPdfs || [];
    const pending = all.filter((p) => !p.uploaded).length;
    chrome.action.setBadgeText({ text: pending > 0 ? String(pending) : "" });
    chrome.action.setBadgeBackgroundColor({ color: "#e6a100" });
  });
}

chrome.runtime.onStartup.addListener(updateBadge);
chrome.runtime.onInstalled.addListener(updateBadge);

function bumpStat(key, delta) {
  chrome.storage.session.get(["stats"], (data) => {
    const stats = data.stats || { downloaded: 0, uploaded: 0, deleted: 0 };
    stats[key] = (stats[key] || 0) + delta;
    chrome.storage.session.set({ stats });
  });
}

function getFileType(filename) {
  const lower = filename.toLowerCase();
  if (lower.endsWith(".pdf")) return "pdf";
  if (lower.endsWith(".xlsx") || lower.endsWith(".xls") || lower.endsWith(".csv")) return "excel";
  if (lower.endsWith(".zip")) return "zip";
  return null;
}

function mimeTypeFor(fileType, filename) {
  if (fileType === "pdf") return "application/pdf";
  if (fileType === "excel") {
    return filename.toLowerCase().endsWith(".csv")
      ? "text/csv"
      : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  }
  if (fileType === "zip") return "application/zip";
  return "application/octet-stream";
}

chrome.downloads.onChanged.addListener((delta) => {
  if (delta.state && delta.state.current === "complete") {
    chrome.downloads.search({ id: delta.id }, (results) => {
      if (!results || !results[0]) return;
      const item = results[0];
      const filename = item.filename || "";

      // Don't track our own activity-log CSV export as a "download" —
      // it's a byproduct of this extension, not a file the user fetched.
      if (item.byExtensionId === chrome.runtime.id) return;
      if (filename.includes("drive_uploader_activity_") || filename.includes("all_users_activity_")) return;

      const fileType = getFileType(filename);

      if (fileType) {
        const fileName = filename.split(/[\\/]/).pop();
        const newEntry = {
          id: item.id,
          fileName: fileName,
          fileType: fileType,
          sourceUrl: item.finalUrl || item.url || "",
          time: Date.now()
        };

        // Always read the latest list from storage first — the in-memory
        // array does NOT survive service worker restarts in Manifest V3.
        chrome.storage.session.get(["recentPdfs"], (data) => {
          const existing = data.recentPdfs || [];
          // avoid duplicate entries for the same download id
          const filtered = existing.filter((p) => p.id !== newEntry.id);
          const updated = [newEntry, ...filtered]; // no limit — keep full history
          chrome.storage.session.set({ recentPdfs: updated }, updateBadge);
        });

        bumpStat("downloaded", 1);
        logActivity("Downloaded", fileName, fileType, fileType);
      }
    });
  }
});

function getAuthToken() {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      const err = chrome.runtime.lastError;
      if (err || !token) {
        reject(err ? err.message : "no token returned");
      } else {
        resolve(token);
      }
    });
  });
}

async function listDriveFolders(parentId) {
  const token = await getAuthToken();
  const parent = parentId || "root";
  const query = encodeURIComponent(
    `'${parent}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false`
  );
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name)&pageSize=100&orderBy=name`,
    { headers: { Authorization: "Bearer " + token } }
  );
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error ? data.error.message : "Could not list folders");
  }
  return data.files || [];
}

async function uploadToDrive(pdfEntry, folderId) {
  const { sourceUrl, fileType } = pdfEntry;
  const fileName = pdfEntry.renamedName || pdfEntry.fileName;
  const token = await getAuthToken();

  if (!sourceUrl) {
    throw new Error("No source URL available for this file.");
  }

  const fileResponse = await fetch(sourceUrl);
  if (!fileResponse.ok) {
    throw new Error("Could not re-fetch source file: HTTP " + fileResponse.status);
  }
  const fileBlob = await fileResponse.blob();

  const metadata = { name: fileName, mimeType: mimeTypeFor(fileType, fileName) };
  if (folderId) {
    metadata.parents = [folderId];
  }
  const form = new FormData();
  form.append("metadata", new Blob([JSON.stringify(metadata)], { type: "application/json" }));
  form.append("file", fileBlob);

  const uploadResponse = await fetch(
    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
    {
      method: "POST",
      headers: { Authorization: "Bearer " + token },
      body: form
    }
  );

  const result = await uploadResponse.json();
  if (!uploadResponse.ok) {
    throw new Error(result.error ? result.error.message : "Unknown upload error");
  }
  return result;
}

async function uploadBytesToDrive(arrayBuffer, fileName, mimeType, folderId) {
  const token = await getAuthToken();
  const metadata = { name: fileName, mimeType: mimeType || "application/octet-stream" };
  if (folderId) metadata.parents = [folderId];

  const fileBlob = new Blob([arrayBuffer], { type: mimeType || "application/octet-stream" });
  const form = new FormData();
  form.append("metadata", new Blob([JSON.stringify(metadata)], { type: "application/json" }));
  form.append("file", fileBlob);

  const res = await fetch(
    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
    { method: "POST", headers: { Authorization: "Bearer " + token }, body: form }
  );
  const result = await res.json();
  if (!res.ok) {
    throw new Error(result.error ? result.error.message : "Unknown upload error");
  }
  return result;
}

function markUploadedInStorage(id) {
  return new Promise((resolve) => {
    chrome.storage.session.get(["recentPdfs"], (data) => {
      const pdfs = data.recentPdfs || [];
      const updated = pdfs.map((p) => (String(p.id) === String(id) ? { ...p, uploaded: true } : p));
      chrome.storage.session.set({ recentPdfs: updated }, () => {
        updateBadge();
        resolve();
      });
    });
  });
}

// Listen for manual upload requests from the popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "UPLOAD_PDF") {
    uploadToDrive(msg.pdf, msg.folderId)
      .then(async (result) => {
        bumpStat("uploaded", 1);
        const wasAlreadyUploaded = !!msg.pdf.uploaded;
        await markUploadedInStorage(msg.pdf.id);
        logActivity(
          wasAlreadyUploaded ? "Re-uploaded" : "Uploaded",
          msg.pdf.renamedName || msg.pdf.fileName,
          msg.pdf.fileType,
          msg.pdf.fileType
        );
        sendResponse({ success: true, result });
      })
      .catch((err) => sendResponse({ success: false, error: err.message || String(err) }));
    return true; // keep channel open for async response
  }
  if (msg.type === "UPLOAD_BLOB") {
    // Bytes are sent from the popup as base64 (safer for message transfer
    // than a raw ArrayBuffer) so the actual upload runs here in the
    // background service worker — it keeps going even if the popup closes.
    (async () => {
      try {
        const binary = atob(msg.base64Data);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);

        const result = await uploadBytesToDrive(bytes.buffer, msg.fileName, msg.mimeType, msg.folderId);

        bumpStat("uploaded", 1);
        let wasAlreadyUploaded = false;
        if (msg.entryId) {
          const existing = await new Promise((resolve) => chrome.storage.session.get(["recentPdfs"], resolve));
          const found = (existing.recentPdfs || []).find((p) => String(p.id) === String(msg.entryId));
          wasAlreadyUploaded = !!(found && found.uploaded);
          await markUploadedInStorage(msg.entryId);
        }
        logActivity(
          wasAlreadyUploaded ? "Re-uploaded" : "Uploaded",
          msg.fileName,
          "pdf",
          msg.entryId ? "Merge PDF" : "pdf"
        );
        sendResponse({ success: true, result });
      } catch (err) {
        sendResponse({ success: false, error: err.message || String(err) });
      }
    })();
    return true;
  }
  if (msg.type === "LOG_ACTIVITY") {
    logActivity(msg.action, msg.fileName, msg.fileType, msg.category)
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message || String(err) }));
    return true;
  }
  if (msg.type === "GET_SHARED_LOG") {
    (async () => {
      try {
        const data = await new Promise((resolve) => chrome.storage.local.get(["sharedFolderId"], resolve));
        if (!data.sharedFolderId) throw new Error("No shared folder configured yet.");
        const fileId = await findOrCreateSharedFile(data.sharedFolderId, "shared_activity_log.json", []);
        const log = await readSharedFile(fileId);
        sendResponse({ success: true, log });
      } catch (err) {
        sendResponse({ success: false, error: err.message || String(err) });
      }
    })();
    return true;
  }
  if (msg.type === "CHECK_ADMIN_PASSPHRASE") {
    (async () => {
      try {
        const data = await new Promise((resolve) => chrome.storage.local.get(["sharedFolderId"], resolve));
        if (!data.sharedFolderId) throw new Error("Set up the shared folder ID first.");
        const configFileId = await findOrCreateSharedFile(
          data.sharedFolderId,
          "admin_config.json",
          { adminPassphrase: null }
        );
        const config = await readSharedFile(configFileId);
        if (!config.adminPassphrase) {
          config.adminPassphrase = msg.passphrase;
          await updateSharedFile(configFileId, config);
          sendResponse({ success: true, firstSetup: true });
        } else if (config.adminPassphrase === msg.passphrase) {
          sendResponse({ success: true, firstSetup: false });
        } else {
          sendResponse({ success: false, error: "Incorrect admin passphrase." });
        }
      } catch (err) {
        sendResponse({ success: false, error: err.message || String(err) });
      }
    })();
    return true;
  }
  if (msg.type === "LIST_FOLDERS") {
    listDriveFolders(msg.parentId)
      .then((folders) => sendResponse({ success: true, folders }))
      .catch((err) => sendResponse({ success: false, error: err.message || String(err) }));
    return true;
  }
  if (msg.type === "DELETE_PDF") {
    chrome.storage.session.get(["recentPdfs", "deletedPdfs"], (data) => {
      const pdfs = data.recentPdfs || [];
      const deleted = data.deletedPdfs || [];
      const target = pdfs.find((p) => String(p.id) === String(msg.id));
      const remaining = pdfs.filter((p) => String(p.id) !== String(msg.id));

      if (target) {
        const archived = { ...target, deletedAt: Date.now() };
        const updatedDeleted = [archived, ...deleted.filter((p) => String(p.id) !== String(msg.id))];
        chrome.storage.session.set(
          { recentPdfs: remaining, deletedPdfs: updatedDeleted },
          () => {
            updateBadge();
            logActivity("Deleted", target.renamedName || target.fileName, target.fileType, target.fileType);
            sendResponse({ success: true });
          }
        );
      } else {
        sendResponse({ success: true });
      }
    });
    bumpStat("deleted", 1);
    return true;
  }
  if (msg.type === "RESTORE_PDF") {
    chrome.storage.session.get(["recentPdfs", "deletedPdfs"], (data) => {
      const pdfs = data.recentPdfs || [];
      const deleted = data.deletedPdfs || [];
      const target = deleted.find((p) => String(p.id) === String(msg.id));
      const remainingDeleted = deleted.filter((p) => String(p.id) !== String(msg.id));

      if (target) {
        const restored = { ...target };
        delete restored.deletedAt;
        const updatedPdfs = [restored, ...pdfs.filter((p) => String(p.id) !== String(msg.id))];
        chrome.storage.session.set(
          { recentPdfs: updatedPdfs, deletedPdfs: remainingDeleted },
          () => {
            updateBadge();
            sendResponse({ success: true });
          }
        );
      } else {
        sendResponse({ success: false, error: "Not found in deleted archive" });
      }
    });
    return true;
  }
});
